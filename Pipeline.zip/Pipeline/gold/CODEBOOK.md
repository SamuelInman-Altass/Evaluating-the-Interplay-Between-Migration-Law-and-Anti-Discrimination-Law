# Gold set annotation codebook

Version 0.1. This defines how a human coder assigns the four gold labels used to
validate the stance scorer. Consistency across coders is what makes the set
usable, so read the decision rules before labelling and keep this open while you
work. British spelling, spaced hyphens and unspaced slashes throughout.

## 1. What the gold set is for

The pipeline assigns every segment a stance toward legal protection of religious
minorities in labour-migration contexts. Those labels are only trustworthy if
they agree with expert human judgement. The gold set is a sample of real
segments, hand-labelled independently of the model, against which `validate-agree`
computes Cohen's kappa (stance), Krippendorff's alpha (score) and F1 (frames).

Read that word independently carefully. If the human labels are produced by the
same model family being validated, the agreement statistic is circular and tells
you nothing. The draft labels shipped in `gold_seed.csv` are a review aid to save
you time, not ground truth. Treat them as a starting point to confirm or
overturn on your own reading. For any agreement number you report, the operative
labels must be yours or another human coder's.

## 2. Unit of analysis

One row = one segment as the pipeline emits it (a recital, a holding paragraph, a
speech turn, a guidance section). Label the segment on its own text. Do not
import knowledge of the wider case outcome unless it appears in the segment.

## 3. The four labels

You assign four things per segment: stance, score, on_topic, frames.

### 3.1 on_topic (label this first)

TRUE if the segment bears on religion/belief and/or migration-status rights in a
way relevant to the study. FALSE if the topical match is incidental (a customs
or milk-levy judgment that happens to contain a keyword, a child-welfare case
where "veil" appears with no religious-manifestation issue).

If on_topic is FALSE, set stance to neutral, score to 0.0 and frames to empty.
Everything below applies only to on_topic TRUE segments.

### 3.2 stance (nominal, four classes)

- protective: the language mandates or widens protection, allocates the burden
  onto the state or employer, applies close scrutiny to an interference, or
  opens/strengthens a remedy.
- restrictive: the language makes protection conditional, shifts the burden onto
  the rights-holder, invokes neutrality/public order/proportionality to narrow a
  claim, or expands compliance/enforcement exposure.
- mixed: the segment carries both directions with neither clearly dominant (for
  example a neutrality aim accepted in principle but fenced with a necessity
  test), or it reports restrictive reasoning while framing a protective question.
- neutral: descriptive, procedural or definitional language with no protective or
  restrictive valence of its own.

### 3.3 score (interval, minus 1 to plus 1)

A continuous reading of the same axis. Anchor points:

- plus 0.7 to plus 1.0  strong protective holding (interference quashed, remedy
  widened, close scrutiny imposed)
- plus 0.3 to plus 0.6  protective but qualified or partly procedural
- minus 0.2 to plus 0.2  mixed or near-neutral
- minus 0.6 to minus 0.3 restrictive but qualified
- minus 1.0 to minus 0.7 strong restrictive holding (claim defeated, burden
  shifted onto the rights-holder, enforcement exposure widened)

stance and score must be coherent: a protective stance should not carry a
negative score.

### 3.4 frames (multi-label, zero or more)

Tag every frame the segment genuinely invokes. Do not force a frame. Definitions
and cues are in section 5.

## 4. Decision rules and edge cases

These are the calls that most often split coders. Fix them here.

- Attributed vs endorsed reasoning. A facts segment often narrates a lower body's
  restrictive reasoning without the deciding court adopting it. Score the legal
  valence the language expresses, but cap the magnitude when the reasoning is
  merely reported rather than endorsed. Reported restriction usually lands at
  mixed or mild restrictive, not strong restrictive. The seed item
  `e2390/2022:key_facts` is the worked example.
- Facts vs holding. Pure factual or procedural narration with no normative pull
  is neutral, even in a case with a protective outcome. Label the segment, not
  the case.
- Procedure as protection. In this corpus a great deal of protection is
  procedural (the right to an oral hearing under Article 47(2), duties to clarify
  evidence). Treat a procedural safeguard that conditions a removal or a refusal
  as protective, tagged access_to_remedies and usually strict_scrutiny.
- Proportionality cuts both ways. A proportionality test that raises the bar for
  interference is protective; one that absorbs a claim into a managerial or state
  interest is restrictive. Read the direction, do not tag on the word alone.
- Non-English originals. Some FRA and EUR-Lex segments are translations or carry
  foreign-language fragments. Label from the meaning. Flag in the note column if
  the text is too garbled to label and set it aside rather than guessing.
- Boilerplate. Standard recitals and reissued guidance recur verbatim. Label them
  once as you would any segment; near-duplicates are collapsed upstream by dedup,
  so you should rarely see repeats.

## 5. Frame taxonomy

Each frame with its definition, positive cues and the frame it is most often
confused with.

- manifestation: religion treated as a right to be exercised (dress, observance,
  worship, conversion). Cue: the practice itself is the protected object.
  Confused with dignity_pluralism (which is about group standing, not the act).
- dignity_pluralism: minority presence framed as part of the democratic order.
  Cue: equal standing, respect, non-stigmatisation. Confused with manifestation.
- indirect_discrimination: a neutral rule imposing a group-specific burden. Cue:
  facially neutral measure, disparate impact. Confused with neutrality_corporate.
- strict_scrutiny: an interference is said to need weighty justification or close
  review. Cue: pressing need, least restrictive means, careful examination.
  Confused with proportionality_balancing (which can dilute rather than tighten).
- access_to_remedies: complaint, hearing or enforcement channels framed as
  protection. Cue: right to be heard, effective remedy, Article 47. Confused with
  compliance_audit (enforcement as risk, not as remedy).
- integration_cohesion: protection made conditional on fitting governing norms.
  Cue: integration expectations, social cohesion, shared values as a condition.
- neutrality_corporate: religious visibility reframed as operational or
  commercial disruption. Cue: employer image, customer-facing neutrality, dress
  codes framed as business need. Confused with indirect_discrimination.
- public_order_border: status or border control taking precedence over equal
  treatment. Cue: immigration control, expulsion, Dublin allocation, public
  order. Confused with proportionality_balancing.
- proportionality_balancing: a claim absorbed into managerial or state interests
  through a balancing move. Cue: balancing exercise resolved against the claimant.
- compliance_audit: frontline actors incentivised to avoid regulatory risk. Cue:
  penalties, checks, civil penalty regimes, right-to-work verification, audit.

## 6. Labelling workflow

1. Read the segment once without the draft label.
2. Set on_topic. If FALSE, fill the neutral defaults and move on.
3. Set stance, then score, checking they cohere.
4. Tag frames.
5. Only then glance at the draft label in `gold_seed.csv`. Where you differ,
   trust your reading and overwrite. Note any systematic disagreement, it tells
   you where the scorer's prompt anchors need fixing.

## 7. Reliability and adjudication

- Have at least two coders label an overlapping subset of 50 to 100 segments.
- Compute inter-annotator agreement on that overlap (the same kappa/alpha the
  harness uses on human vs model). Target stance kappa above 0.6 before trusting
  the gold set itself. If coders cannot agree, the scheme is ambiguous and this
  codebook needs tightening, not the coders.
- Adjudicate disagreements by discussion and record the resolved label. Keep the
  original coder columns so the adjudication is auditable.

## 8. Building the operative gold set from the data

`gold/gold_seed.csv` is a small set of worked examples, hand-checked, with
rationales. It is for calibration and for the anchors in the scorer, not for the
headline agreement number. The operative gold set is derived from your corpus:

    python -m ocpsg.pipeline gold-build --config config.yaml --n 400

This pulls real segments out of the ingested data, stratified across source,
tier, jurisdiction and topical cluster (and, once the corpus is scored, across
the model's stance so all four classes are represented rather than swamped by
neutral text). It writes a blind template you hand-label against this codebook.

- Aim for 300 to 500 labelled segments for a publishable validation.
- The builder caps any single source and lifts small on-topic sources, so a 4 GB
  dump does not dominate the labelling set.
- Ensure all four stances and both on_topic values end up represented. Re-run
  `gold-build` after scoring to get the stance-balanced draw.

## 9. Known gaps in the shipped seed exemplars

- The seed exemplars only cover FRA and EUR-Lex caselaw, because those were the
  records available at build time. This does not limit the operative set:
  `gold-build` samples every source present in your corpus.
- The seed exemplars contain no clean restrictive on-topic case. When you label
  the `gold-build` draw, make sure restrictive cases (a workplace neutrality ban
  upheld, right-to-work enforcement widened) are captured so the scorer's
  restrictive recall can be measured.
