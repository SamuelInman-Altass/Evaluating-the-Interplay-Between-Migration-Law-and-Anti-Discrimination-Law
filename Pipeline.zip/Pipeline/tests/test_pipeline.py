"""Regression tests for the deterministic stages.

The adapters and the relevance gate are where silent breakage hits hardest — a
schema drift in one source quietly drops or mislabels thousands of segments.
These pin the behaviour smoke-tested against real sample records. Run: pytest -q
"""
from ocpsg.adapters import ADAPTERS
from ocpsg.relevance import passes, matched_clusters
from ocpsg.segment import split_document
from ocpsg.derive import (derive_year, derive_tier, derive_jurisdiction,
                          derive_apex, derive_referring_country)
import pandas as pd


# --- sample records lifted from the actual corpus ---
FRA = {"document_id": "fra:at-e32962017", "decision_date": "2018-02-26",
       "country": "Austria", "deciding_body": "Constitutional Court",
       "deciding_body_type": "National Court/Tribunal",
       "ecli": "ECLI:AT:VFGH:2018", "segment_id": "fra:x:key_facts:1",
       "segment_type": "key_facts", "source_url": "https://fra/x",
       "text": ("The complainant, an Iranian national, applied for international "
                "protection. He brought forward to be Christian and would be "
                "persecuted in Iran. The Court denied international protection.")}

EURLEX_MILK = {"celex": "61994TJ0087", "ecli": "ECLI:EU:T:2006:135",
               "date_document": "2006-05-30", "segment_order": 2,
               "segment_type": "legal_context", "source_url": "https://eur/x",
               "segment_text": ("Council Regulation (EEC) No 1078/77 introducing "
                                 "a system of premiums for the non-marketing of milk.")}


def test_fra_adapter_reads_country_and_apex():
    seg = next(ADAPTERS["fra_caselaw"](FRA, "fra_caselaw", "adjudicative", "from_field"))
    assert seg.jurisdiction == "Austria"
    assert seg.year == 2018
    assert seg.is_apex is True            # "constitutional court" marker
    assert seg.tier == "adjudicative"


def test_relevance_gate_drops_milk_keeps_religion():
    keep_milk, _ = passes(EURLEX_MILK["segment_text"], "gate")
    keep_relig, hits = passes(FRA["text"], "gate")
    assert keep_milk is False
    assert keep_relig is True
    assert "Religion" in hits


def test_keep_policy_never_drops():
    keep, _ = passes(EURLEX_MILK["segment_text"], "keep")
    assert keep is True


def test_migration_cluster_matches():
    assert "MigrationStatus" in matched_clusters(
        "The claimant had no recourse to public funds and sought leave to remain.")


def test_split_document_paragraphs():
    txt = ("The Constitutional Court found a violation of the right to a fair "
           "hearing under Article 47 of the Charter.\n\n"
           "The Federal Administrative Court should not have refrained from "
           "holding an oral hearing in the present asylum proceedings.")
    out = split_document(txt)
    assert len(out) == 2


def test_split_drops_scraps():
    assert split_document("too short") == []   # under the 40-char floor


def test_simhash_near_duplicates_closer_than_unrelated():
    pass  # near-dup simhash retired in favour of streaming exact-dup (see dedup.run)


def test_dedup_collapses_repeats(tmp_path):
    from ocpsg.dedup import run
    seg = tmp_path / "segments" / "fra_caselaw"
    seg.mkdir(parents=True)
    pd.DataFrame({
        "segment_id": ["s1", "s2", "s3"],
        "document_id": ["d1", "d1", "d2"], "source": ["fra_caselaw"] * 3,
        "tier": ["adjudicative"] * 3, "jurisdiction": ["Austria"] * 3,
        "year": [2018] * 3, "is_apex": [True] * 3, "char_count": [60, 60, 70],
        "text": [
            "the applicant was granted subsidiary protection by the federal office",
            "the applicant was granted subsidiary protection by the federal office",  # exact dup
            "an entirely unrelated passage about milk levies and reference quantities",
        ]}).to_parquet(seg / "part-00000.parquet")
    stats = run(tmp_path)
    assert stats["segments_in"] == 3
    assert stats["representatives"] == 2          # s1/s2 collapse, s3 stands
    reps = pd.read_parquet(tmp_path / "segments_dedup" / "representatives.parquet")
    assert len(reps) == 2
    dm = pd.read_parquet(tmp_path / "segments_dedup" / "dup_map.parquet").set_index("segment_id")
    assert dm.loc["s1", "dup_group"] == dm.loc["s2", "dup_group"]


# --- metadata derived from the data, not config ---
def test_derive_tier_from_document_form():
    assert derive_tier({"document_form": "judgment", "celex": "6..."}, "guidance") == "adjudicative"
    assert derive_tier({"document_form": "Regulation", "celex": "3..."}, None) == "legislative"
    assert derive_tier({"deciding_body_type": "National Court/Tribunal"}, None) == "adjudicative"
    assert derive_tier({"document_type": "guidance", "govuk_url": "x"}, None) == "guidance"


def test_derive_tier_falls_back_when_silent():
    assert derive_tier({"full_text": "a debate"}, "deliberative") == "deliberative"


def test_derive_jurisdiction_prefers_data():
    assert derive_jurisdiction({"country": "Austria/ Constitutional Court"}, "from_field") == "Austria"
    assert derive_jurisdiction({"respondent": "Germany"}, "ECtHR") == "Germany"
    assert derive_jurisdiction({"celex": "62018CJ0..."}, "EU") == "EU"
    assert derive_jurisdiction({"full_text": "x"}, "UK") == "UK"       # fallback


def test_derive_apex_and_referring_country():
    assert derive_apex({"celex": "6...", "document_form": "judgment"}) is True
    assert derive_apex({"appno": "1234/05"}) is True                    # ECtHR
    assert derive_apex({"document_form": "guidance"}, court="First-tier Tribunal") is False
    assert derive_referring_country({"referring_court_country": "Spain"}) == "Spain"


def test_derive_year_scans_candidate_keys():
    assert derive_year({"decision_date": "2018-02-26"}) == 2018
    assert derive_year({"public_updated_at": "2021-07-30T13:29:00+01:00"}) == 2021
    assert derive_year({"nothing": "here"}) is None


def test_fra_adapter_now_derives_everything():
    seg = next(ADAPTERS["fra_caselaw"](FRA, "fra_caselaw", None, None))  # no config defaults
    assert seg.jurisdiction == "Austria"      # from country field
    assert seg.tier == "adjudicative"         # from deciding_body_type
    assert seg.is_apex is True                # constitutional court
    assert seg.year == 2018                   # from decision_date


def test_preflight_check_status_and_derivation(tmp_path):
    import json
    from ocpsg.preflight import check_source
    base = tmp_path
    (base / "OCPSG 2").mkdir(parents=True)
    (base / "OCPSG 2" / "FRA_Caselaw.json").write_text(json.dumps([{
        "document_id": "fra:x", "country": "Austria",
        "deciding_body_type": "National Court/Tribunal",
        "deciding_body": "Constitutional Court", "decision_date": "2018-02-26",
        "segment_id": "fra:x:key_facts:1", "segment_type": "key_facts",
        "text": "An Iranian national claimed persecution on grounds of religious conversion."}]))
    src = {"name": "fra_caselaw", "path": "OCPSG 2/FRA_Caselaw.json",
           "adapter": "fra_caselaw", "tier": "adjudicative",
           "jurisdiction": "from_field", "relevance": "keep"}
    row = check_source(src, base)
    assert row["status"] == "OK"
    assert row["format"] == "json-array"
    assert row["first_record_derived"]["jurisdiction"] == "Austria"
    assert row["first_record_derived"]["tier"] == "adjudicative"

    missing = check_source({**src, "path": "OCPSG 2/nope.json"}, base)
    assert missing["status"] == "MISSING"
    from ocpsg.gold import build_gold_set, HUMAN_COLS
    import numpy as np
    seg = tmp_path / "segments" / "mix"
    seg.mkdir(parents=True)
    rng = np.random.default_rng(0)

    def block(source, tier, jur, cluster, k):
        return pd.DataFrame({
            "segment_id": [f"{source}-{i}" for i in range(k)],
            "document_id": [f"{source}-d{i//3}" for i in range(k)],
            "source": source, "tier": tier, "jurisdiction": jur,
            "year": 2020, "segment_type": "para", "cluster_labels": cluster,
            "text": [f"{source} {cluster} passage {i}" for i in range(k)]})
    pd.concat([
        block("eurlex_caselaw", "adjudicative", "EU", "Religion", 500),   # dominant
        block("fra_caselaw", "adjudicative", "Austria", "Religion", 20),  # tiny
        block("govuk_guidance", "guidance", "UK", "MigrationStatus", 80),
    ], ignore_index=True).to_parquet(seg / "part-00000.parquet")

    build_gold_set(tmp_path, n=60, seed=1, max_source_frac=0.4)
    tmpl = pd.read_csv(tmp_path / "validation" / "gold_template.csv")

    assert len(tmpl) <= 60
    assert tmpl["text"].notna().all()                         # real text pulled from data
    for c in HUMAN_COLS:
        assert (tmpl[c].fillna("") == "").all()               # blind template
    # dominant source capped, tiny source represented, >1 tier present
    assert (tmpl["source"] == "eurlex_caselaw").mean() <= 0.4 + 1e-9
    assert (tmpl["source"] == "fra_caselaw").sum() >= 1
    assert tmpl["tier"].nunique() >= 2


# --- local NLI stance backend (no API) ---
class _StubClf:
    def __call__(self, texts, labels, multi_label=False):
        from ocpsg.stance_local import STANCE_HYP, ONTOPIC_HYP, FRAME_HYP
        if isinstance(texts, str):
            texts = [texts]
        res = []
        for t in texts:
            sc = []
            for lab in labels:
                if lab == STANCE_HYP["protective"]:
                    s = 0.9 if "PROT" in t else 0.1
                elif lab == STANCE_HYP["restrictive"]:
                    s = 0.9 if "RESTR" in t else 0.1
                elif lab == STANCE_HYP["neutral"]:
                    s = 0.9 if "NEUT" in t else 0.1
                elif lab == ONTOPIC_HYP:
                    s = 0.9 if "ONTOPIC" in t else 0.1
                elif lab == FRAME_HYP["manifestation"]:
                    s = 0.9 if "MANIF" in t else 0.1
                else:
                    s = 0.1
                sc.append(s)
            res.append({"labels": list(labels), "scores": sc})
        return res


def test_nli_scorer_maps_labels():
    from ocpsg.stance_local import NLIScorer
    cfg = {"stance": {"ontopic_threshold": 0.5, "frame_threshold": 0.5}}
    sc = NLIScorer(cfg, classifier=_StubClf())
    out = sc.score(["PROT ONTOPIC", "RESTR ONTOPIC", "PROT RESTR ONTOPIC",
                    "NEUT", "PROT ONTOPIC MANIF"])
    assert out[0]["stance"] == "protective" and out[0]["on_topic"]
    assert out[1]["stance"] == "restrictive"
    assert out[2]["stance"] == "mixed"
    assert out[3]["stance"] == "neutral" and not out[3]["on_topic"]
    assert "manifestation" in out[4]["frames"]


def test_score_frame_local_nli_end_to_end(tmp_path, monkeypatch):
    import ocpsg.stance_local as sl
    monkeypatch.setattr(sl, "_nli_pipeline", lambda cfg: _StubClf())
    df = pd.DataFrame({
        "segment_id": ["a", "b"], "document_id": ["d1", "d1"],
        "source": ["fra_caselaw"] * 2, "tier": ["adjudicative"] * 2,
        "jurisdiction": ["Austria"] * 2, "year": [2018, 2018],
        "is_apex": [True, True], "char_count": [30, 30],
        "text": ["PROT ONTOPIC", "RESTR ONTOPIC"]})
    cfg = {"stance": {"cache_db": "c.sqlite", "batch_size": 8,
                      "ontopic_threshold": 0.5, "frame_threshold": 0.5}}
    out = sl.score_frame_local(df, cfg, tmp_path, backend="nli")
    assert set(["stance", "score", "frames", "on_topic", "confidence"]).issubset(out.columns)
    assert out.set_index("segment_id").loc["a", "stance"] == "protective"
    assert out.set_index("segment_id").loc["b", "stance"] == "restrictive"


# --- wrapped-object files (metadata header + records under a key) ---
def test_iter_records_handles_wrapped_and_jsonl(tmp_path):
    import json
    from ocpsg.ingest import _iter_records
    wrapped = {"metadata": {"n": 2}, "documents": [
        {"case_id": "a", "full_text": "x"}, {"case_id": "b", "full_text": "y"}]}
    (tmp_path / "w.json").write_text(json.dumps(wrapped, indent=2))
    assert sum(1 for _ in _iter_records(tmp_path / "w.json")) == 2          # autodetect
    assert sum(1 for _ in _iter_records(tmp_path / "w.json", "documents")) == 2

    with open(tmp_path / "l.json", "w") as f:
        f.write(json.dumps({"case_id": "c", "full_text": "z"}) + "\n")
        f.write(json.dumps({"case_id": "d", "full_text": "w"}) + "\n")
    assert sum(1 for _ in _iter_records(tmp_path / "l.json")) == 2          # jsonl


def test_hudoc_adapter_real_schema():
    from ocpsg.adapters import ADAPTERS
    rec = {"id": "001-1", "citation": {"case_name": "CASE OF X v. THE UNITED KINGDOM",
           "application_no": "9/20", "date": "2021-03-04"},
           "texts": {"raw": "JUDGMENT. The applicant complained about a restriction on "
                     "religious dress in the workplace under Article 9 of the Convention."},
           "proportionality_excerpts": [{"trigger_term": "legitimate aim",
                     "excerpt": "The measure pursued the legitimate aim of protecting the "
                     "rights of others and was proportionate in the circumstances."}]}
    segs = list(ADAPTERS["hudoc"](rec, "hudoc", "adjudicative", "ECtHR"))
    assert len(segs) == 2
    assert segs[0].segment_type == "proportionality_excerpt"
    assert all(s.jurisdiction == "United Kingdom" for s in segs)   # parsed from case name
    assert all(s.year == 2021 and s.is_apex for s in segs)
