# OCPSG protectiveness pipeline

Implements the deck pipeline over the nine-file corpus in `~/Downloads`:

```
ingest → segment → relevance gate → zero-shot stance/frame (LLM, cached)
       → embeddings (CUDA) → P(j,y,t) + bootstrap CIs → implementation gap
       → semantic drift → Section V linkage interface
```

Runs locally — the corpus (~9.6 GB) never leaves your machine, and the LLM
scorer is the only thing that hits the network.

## Install

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

On Apple Silicon, `pip install torch` (pulled in by requirements) already gives
you the `mps` GPU build - do NOT install a CUDA wheel. On a Linux/NVIDIA box,
install the matching CUDA torch instead and set the `device:` fields to `cuda`.

No API key is needed by default: the stance scorer runs locally (see Stance
backends below). You only set `ANTHROPIC_API_KEY` if you deliberately switch to
the anthropic backend.

## Stance backends (no API by default)

The scorer is pluggable via `stance.backend` in `config.yaml`:

- **`nli`** (default) - a local zero-shot classifier (HuggingFace transformers).
  No API, no key, no per-token cost, runs on `mps`/`cpu`, deterministic. One-time
  model download (~1.5 GB). Best default for a large corpus on a laptop.
- **`ollama`** - a local generative model via Ollama, using the same prompt and
  JSON contract as the API path. Higher quality on subtle legal stance, slower.
  Needs Ollama running and a model pulled (`ollama pull llama3.1:8b`).
- **`anthropic`** - the API scorer. Optional; requires `pip install anthropic`
  and `ANTHROPIC_API_KEY`.

All three emit the same columns, so aggregation, drift and validation are
identical. Which to trust is empirical: build the gold set and check agreement.
The `nli` backend is deterministic, so its `stability` noise floor is zero by
construction (the command reports this and skips).

## Run

First, confirm the config maps onto what is actually on disk (checks every path
exists, sniffs format, validates each adapter against the first record, and
flags any .json in the folders that config does not reference):

```bash
python -m ocpsg.pipeline check --config config.yaml
```

Then see what the pipeline derives from your actual files (tier, jurisdiction,
year, apex are read off each record, not hard-coded):

```bash
python -m ocpsg.pipeline profile --config config.yaml --n 500
```

This samples each file and reports the derived tier/jurisdiction distributions,
year range, apex rate, gate keep-rate and which fields were found - the fastest
way to confirm the HUDOC adapter picked up the right keys before a full run.

Then smoke-test the chain (`--limit 200` keeps the first run quick; only the
anthropic backend prompts a cost gate, the local backends just run):

```bash
python -m ocpsg.pipeline ingest --config config.yaml
python -m ocpsg.pipeline dedup  --config config.yaml          # collapse boilerplate
python -m ocpsg.pipeline score  --config config.yaml --limit 200
python -m ocpsg.pipeline embed  --config config.yaml
python -m ocpsg.pipeline aggregate --config config.yaml
python -m ocpsg.pipeline drift  --config config.yaml
```

Then the full run (`score` prints a cost estimate and waits for confirmation):

```bash
python -m ocpsg.pipeline all --config config.yaml
```

Stages are resumable — each writes parquet to `work_dir`, every LLM call is
cached in SQLite, and each stage drops a provenance manifest under
`work_dir/manifests/`. `dedup` is optional but cuts scoring cost; if run, `score`
automatically scores only the unique representatives.

### Validate the instrument (do this before trusting any number)

```bash
python -m ocpsg.pipeline validate-export --config config.yaml --n 300
#  -> hand-label work_dir/validation/gold_template.csv (columns:
#     human_stance, human_score, human_on_topic, human_frames)
python -m ocpsg.pipeline validate-agree  --config config.yaml
#  -> Cohen's kappa (stance), Krippendorff's alpha (score), F1 (frames)
```

Also measure the model's own noise floor (how often it disagrees with itself):

```bash
python -m ocpsg.pipeline stability --config config.yaml --n 100 --k 5
```

A stance kappa below ~0.6, or low self-agreement, means the index is tracking
model idiosyncrasy rather than the law — fix the prompt/anchors in `stance.py`
before scaling up.

### Gold set (`gold/`)

`gold/CODEBOOK.md` is the annotation scheme (label definitions, decision rules,
frame taxonomy, IAA protocol). `gold/gold_seed.csv` is a small set of worked
exemplars with rationales.

Build the operative gold set from your own data - it pulls real segments out of
the ingested corpus, stratified across source, tier, jurisdiction and topical
cluster (and across model stance once scored, so the four classes are balanced
rather than swamped by neutral text):

```bash
python -m ocpsg.pipeline gold-build --config config.yaml --n 400
#  -> hand-label work_dir/validation/gold_template.csv against gold/CODEBOOK.md
python -m ocpsg.pipeline validate-agree --config config.yaml
```

The builder caps any single source and lifts small on-topic sources, so a 4 GB
dump cannot dominate the labelling set. A coverage manifest is written alongside
the template. The seed CSV can still be used directly for a quick check:

```bash
python -m ocpsg.pipeline validate-agree --config config.yaml --gold gold/gold_seed.csv
```

The draft labels in the seed are a review aid, not ground truth - a gold set
labelled by the same model family it validates is circular, so review and
overwrite them on your own reading.

## Outputs (in `work_dir/indices/`)

| file | what |
|---|---|
| `protectiveness_index.csv` | P(j,y,t) with 95% cluster-bootstrap CIs |
| `implementation_gap.csv` | gap(j,y) = formal − operational protectiveness |
| `semantic_drift.csv` | per-term contextual drift over time |
| `stance_stability.csv` | model self-agreement (instrument noise floor) |
| `linked_panel.csv` | indices joined to your outcome data (once supplied) |
| `validation/agreement_report.json` | human-vs-model kappa / alpha / F1 |

`protectiveness_index.csv` now also carries `mean_confidence`, `mixed_share`
(polarization proxy) and `frame_shares` per cell, so a trend in P can be checked
against a shift in what was measured rather than mistaken for a real change.

## Three things you must verify

1. **HUDOC field names** — `adapt_hudoc` in `adapters.py` reads from a list of
   candidate keys covering common export shapes. Run `profile` to confirm the
   right text/id/date/jurisdiction fields were found for your dump; adjust the
   candidate keys if `profile` shows gaps.
2. **LLM cost rates** — the rates in `stance.estimate_cost` are placeholders.
   Confirm current pricing before a full run.
3. **Section V outcome data** — linkage is stubbed until you drop an
   `outcomes.csv` (schema in `linkage.py`) into `work_dir`.

## Design notes

- **Metadata is derived from the data, not hard-coded.** Tier, jurisdiction,
  year and apex status are read off each record (`derive.py`): `document_form`
  and `deciding_body_type` give tier, `country` / `respondent` / `celex` give
  jurisdiction, court name plus document form give apex. The tier/jurisdiction in
  `config.yaml` are only fallbacks for when the data is silent. `profile` shows
  what actually gets derived. (Relevance policy stays in config - it is a
  research choice, not something the data can tell you.)
- **Relevance gate is lexical and recall-favoured** — its only job is to stop
  you paying tokens on the 4 GB off-topic EUR-Lex caselaw tail. True topical
  filtering is the model's `on_topic` flag, applied at aggregation, which is
  where keyword false positives (e.g. a child-death case matching "veil") are
  dropped.
- **Bootstrap resamples documents, not segments**, because segments within one
  judgment aren't independent.
- **Document-family weighting** (`confidence / segments-per-document`) stops one
  long judgment dominating a P(j,y,t) cell.
