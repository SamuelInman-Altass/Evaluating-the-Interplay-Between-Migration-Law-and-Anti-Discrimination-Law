"""Build the gold labelling set from the datasets themselves.

The seed CSV in gold/ is a small hand-checked exemplar set. The *operative* gold
set should be a real sample of your corpus, which this derives: it reads the
ingested segments (dedup representatives if available), stratifies across
source x tier x jurisdiction x topical-cluster - and, if the corpus has been
scored, across the model's stance too - then allocates the sample as evenly as
possible across those cells so the labelling set is not swamped by whatever
source or stance happens to be largest. No segment text is invented; every row
is pulled from the data.

Output is a BLIND template (segment ids + text + empty human columns) plus a
coverage manifest. Hand-label the template, then `validate-agree` joins your
labels back to the model predictions by segment_id.

    python -m ocpsg.pipeline gold-build --config config.yaml --n 400
"""
from __future__ import annotations
from pathlib import Path
import glob
import json

import numpy as np
import pandas as pd

HUMAN_COLS = ["human_stance", "human_score", "human_on_topic", "human_frames"]
BLIND_COLS = ["segment_id", "source", "tier", "jurisdiction", "year",
              "cluster_labels", "segment_type", "text"]


def _load_ingested(work_dir: Path) -> pd.DataFrame:
    rep = work_dir / "segments_dedup" / "representatives.parquet"
    if rep.exists():
        return pd.read_parquet(rep)
    files = glob.glob(str(work_dir / "segments" / "*" / "*.parquet"))
    if not files:
        raise SystemExit("No ingested segments. Run `ingest` (and optionally "
                         "`dedup`) first.")
    return pd.concat((pd.read_parquet(f) for f in files), ignore_index=True)


def _balanced_allocate(df: pd.DataFrame, strata: list[str], n: int,
                       seed: int, max_source_frac: float) -> pd.DataFrame:
    """Even allocation across strata cells, then top up to n, then cap any one
    source at max_source_frac of the sample."""
    rng = np.random.default_rng(seed)
    groups = list(df.groupby(strata, dropna=False))
    if not groups:
        return df.head(0)
    per = max(1, n // len(groups))

    picks = []
    for _, g in groups:
        take = min(per, len(g))
        picks.append(g.sample(take, random_state=seed))
    sample = pd.concat(picks, ignore_index=True).drop_duplicates("segment_id")

    # top up toward n from the remainder, sampling proportional to cell size
    if len(sample) < n:
        remainder = df[~df["segment_id"].isin(sample["segment_id"])]
        if len(remainder):
            extra = remainder.sample(min(n - len(sample), len(remainder)),
                                     random_state=seed + 1)
            sample = pd.concat([sample, extra], ignore_index=True)

    # cap per-source dominance
    cap = int(np.ceil(n * max_source_frac))
    capped = []
    for src, g in sample.groupby("source"):
        capped.append(g.sample(min(len(g), cap), random_state=seed) if len(g) > cap else g)
    sample = pd.concat(capped, ignore_index=True)

    if len(sample) > n:
        sample = sample.sample(n, random_state=seed)
    return sample.sample(frac=1, random_state=seed).reset_index(drop=True)  # shuffle


def build_gold_set(work_dir: Path, n: int = 400, seed: int = 0,
                   max_source_frac: float = 0.35) -> Path:
    df = _load_ingested(work_dir)

    # topical cluster from the keyword metadata already stored at ingest
    df["cluster_labels"] = df.get("cluster_labels", "").fillna("")
    df["primary_cluster"] = df["cluster_labels"].map(
        lambda s: s.split(",")[0] if s else "none")

    # if the corpus is scored, stratify by stance too so all four classes and
    # the off-topic cases are represented; otherwise stratify by topical cluster
    scored_path = work_dir / "scored.parquet"
    if scored_path.exists():
        sc = pd.read_parquet(scored_path)[["segment_id", "stance", "on_topic"]]
        df = df.merge(sc, on="segment_id", how="left")
        df["stance"] = df["stance"].fillna("(unscored)")
        strata = ["source", "tier", "jurisdiction", "stance"]
    else:
        strata = ["source", "tier", "jurisdiction", "primary_cluster"]

    if "text" not in df or "segment_id" not in df:
        raise SystemExit("Ingested parquet is missing text/segment_id columns.")

    sample = _balanced_allocate(df, strata, n, seed, max_source_frac)

    out = work_dir / "validation"
    out.mkdir(parents=True, exist_ok=True)
    blind = sample[[c for c in BLIND_COLS if c in sample.columns]].copy()
    for c in HUMAN_COLS:
        blind[c] = ""
    blind.to_csv(out / "gold_template.csv", index=False)

    # coverage manifest so you can see the shape of what was drawn
    manifest = {
        "n_requested": n, "n_drawn": int(len(sample)), "seed": seed,
        "strata": strata,
        "by_source": sample["source"].value_counts().to_dict(),
        "by_tier": sample["tier"].value_counts().to_dict(),
        "by_jurisdiction": sample["jurisdiction"].value_counts().head(15).to_dict(),
        "by_primary_cluster": sample["primary_cluster"].value_counts().to_dict(),
    }
    if "stance" in sample:
        manifest["by_model_stance"] = sample["stance"].value_counts().to_dict()
    (out / "gold_build_manifest.json").write_text(json.dumps(manifest, indent=2))

    print(f"  drew {len(sample)} candidate segments from the corpus "
          f"-> {out/'gold_template.csv'}")
    print(f"  by source: {manifest['by_source']}")
    print(f"  by tier:   {manifest['by_tier']}")
    if "by_model_stance" in manifest:
        print(f"  by stance: {manifest['by_model_stance']}")
    print(f"  fill {HUMAN_COLS} (frames = space-separated keys), then "
          f"`validate-agree`. See gold/CODEBOOK.md for the rules.")
    return out / "gold_template.csv"
