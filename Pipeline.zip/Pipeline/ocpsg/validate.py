"""Instrument validation.

The whole index is only as trustworthy as the stance model as an annotator, and
right now nothing measures that. This module closes the loop:

  export   -> a stratified, BLIND sample for a human to hand-label. Model
              predictions are written to a separate file so the labeller isn't
              anchored to them.
  agree    -> once the human column is filled, compute human-vs-model agreement:
                * Cohen's kappa on stance (nominal, 4 classes)
                * Krippendorff's alpha on the continuous score (interval)
                * accuracy + kappa on on_topic (binary)
                * micro / macro F1 on the multi-label frames
                * Pearson & Spearman on human vs model score
                * a stance confusion matrix
              Report these numbers next to P(j,y,t). A kappa below ~0.6 means
              the index is measuring the model's idiosyncrasy, not the law.

Krippendorff's alpha is implemented inline (interval + nominal) to avoid a
dependency; Cohen's kappa / F1 / confusion come from scikit-learn.
"""
from __future__ import annotations
from pathlib import Path
import json

import numpy as np
import pandas as pd

from .schema import FRAMES

HUMAN_COLS = ["human_stance", "human_score", "human_on_topic", "human_frames"]


# --------------------------------------------------------------------------- #
# Export a blind gold sample
# --------------------------------------------------------------------------- #
def export_gold_sample(work_dir: Path, n: int = 300, seed: int = 0,
                       stratify: tuple[str, ...] = ("source", "tier"),
                       min_per_stance: int = 20) -> Path:
    scored = pd.read_parquet(work_dir / "scored.parquet").reset_index(drop=True)
    # proportional stratified sample so every source/tier is represented.
    # Sample per group and concat (avoids groupby.apply moving keys to the index).
    frac = min(1.0, n / max(1, len(scored)))
    parts = [g.sample(max(1, round(len(g) * frac)), random_state=seed)
             for _, g in scored.groupby(list(stratify))]
    sample = pd.concat(parts, ignore_index=True)
    sample = sample.sample(min(n, len(sample)), random_state=seed)

    # A raw corpus is dominated by neutral procedural text, so a proportional
    # sample barely contains protective/restrictive/mixed cases — the ones that
    # actually stress the labels. Top up each stance to a floor so the gold set
    # can estimate per-class agreement rather than just "neutral vs everything".
    if "stance" in scored.columns:
        for st in ("protective", "restrictive", "mixed", "neutral"):
            have = (sample["stance"] == st).sum()
            pool = scored[(scored["stance"] == st) &
                          (~scored["segment_id"].isin(sample["segment_id"]))]
            if have < min_per_stance and len(pool):
                extra = pool.sample(min(min_per_stance - have, len(pool)),
                                    random_state=seed)
                sample = pd.concat([sample, extra], ignore_index=True)
        sample = sample.drop_duplicates("segment_id")

    out = work_dir / "validation"
    out.mkdir(parents=True, exist_ok=True)
    # blind template: text + empty human columns only
    blind = sample[["segment_id", "source", "tier", "jurisdiction", "text"]].copy()
    for c in HUMAN_COLS:
        blind[c] = ""
    blind.to_csv(out / "gold_template.csv", index=False)
    # model predictions kept separate, joined only at scoring time
    keep = ["segment_id", "stance", "score", "on_topic", "frames"]
    sample[keep].to_parquet(out / "model_predictions.parquet", index=False)
    print(f"  wrote {len(blind)} blind rows -> {out/'gold_template.csv'}\n"
          f"  fill columns {HUMAN_COLS} (frames = space-separated keys), then run "
          f"`validate-agree`.")
    return out / "gold_template.csv"


# --------------------------------------------------------------------------- #
# Krippendorff's alpha (inline)
# --------------------------------------------------------------------------- #
def _alpha_interval(a: np.ndarray, b: np.ndarray) -> float:
    """Two-coder interval alpha."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    m = ~(np.isnan(a) | np.isnan(b))
    a, b = a[m], b[m]
    n = len(a)
    if n < 2:
        return float("nan")
    vals = np.concatenate([a, b])
    Do = np.mean((a - b) ** 2)                      # observed disagreement
    De = np.mean([(x - y) ** 2 for x in vals for y in vals])  # expected
    return 1.0 - Do / De if De else float("nan")


def _alpha_nominal(a, b) -> float:
    a, b = np.asarray(a), np.asarray(b)
    m = ~(pd.isna(a) | pd.isna(b))
    a, b = a[m], b[m]
    if len(a) < 2:
        return float("nan")
    Do = np.mean(a != b)
    vals = np.concatenate([a, b])
    pe = sum((np.mean(vals == v)) ** 2 for v in set(vals))
    De = 1 - pe
    return 1.0 - Do / De if De else float("nan")


def _parse_frames(cell) -> set[str]:
    if isinstance(cell, (list, tuple, np.ndarray)):
        return {f for f in cell if f in FRAMES}
    if not cell or not isinstance(cell, str):
        return set()
    return {t for t in cell.replace(",", " ").split() if t in FRAMES}


# --------------------------------------------------------------------------- #
# Agreement report
# --------------------------------------------------------------------------- #
def compute_agreement(work_dir: Path, gold_csv: Path | str | None = None) -> dict:
    from sklearn.metrics import cohen_kappa_score, confusion_matrix, f1_score

    val = work_dir / "validation"
    gold_path = Path(gold_csv) if gold_csv else val / "gold_template.csv"
    gold = pd.read_csv(gold_path)

    # Model predictions: prefer the frozen export; otherwise (e.g. an externally
    # supplied gold file such as the seed set) pull them from scored.parquet for
    # exactly the gold segment_ids.
    mp = val / "model_predictions.parquet"
    if mp.exists():
        preds = pd.read_parquet(mp)
    else:
        scored = pd.read_parquet(work_dir / "scored.parquet")
        preds = scored[["segment_id", "stance", "score", "on_topic", "frames"]]
    df = gold.merge(preds, on="segment_id", how="inner")
    if df.empty:
        raise SystemExit(
            "No overlap between gold segment_ids and model predictions. Score the "
            "corpus first (these segments must be in scored.parquet).")
    hs = df["human_stance"].astype(str).str.strip().str.lower()
    df = df[~hs.isin(["", "nan", "none"])].copy()   # drop unlabelled rows cleanly
    if df.empty:
        raise SystemExit("gold file has no filled human_stance rows yet.")

    rep: dict = {"n_labelled": int(len(df))}

    # stance (nominal)
    hs, ms = df["human_stance"].str.strip(), df["stance"]
    labels = ["protective", "restrictive", "mixed", "neutral"]
    rep["stance_cohen_kappa"] = round(float(cohen_kappa_score(hs, ms, labels=labels)), 3)
    rep["stance_accuracy"] = round(float((hs.values == ms.values).mean()), 3)
    rep["stance_confusion"] = {
        "labels": labels,
        "matrix": confusion_matrix(hs, ms, labels=labels).tolist(),
    }

    # score (interval)
    hsc = pd.to_numeric(df["human_score"], errors="coerce").to_numpy()
    msc = pd.to_numeric(df["score"], errors="coerce").to_numpy()
    rep["score_krippendorff_alpha"] = round(_alpha_interval(hsc, msc), 3)
    ok = ~(np.isnan(hsc) | np.isnan(msc))
    if ok.sum() > 2:
        rep["score_pearson"] = round(float(np.corrcoef(hsc[ok], msc[ok])[0, 1]), 3)
        rep["score_spearman"] = round(float(
            pd.Series(hsc[ok]).corr(pd.Series(msc[ok]), method="spearman")), 3)

    # on_topic (binary)
    def _tobool(x):
        return str(x).strip().lower() in ("1", "true", "yes", "y", "t")
    ho = df["human_on_topic"].map(_tobool)
    mo = df["on_topic"].astype(bool)
    rep["on_topic_accuracy"] = round(float((ho.values == mo.values).mean()), 3)
    rep["on_topic_cohen_kappa"] = round(float(cohen_kappa_score(ho, mo)), 3)

    # frames (multi-label)
    hf = df["human_frames"].map(_parse_frames)
    mf = df["frames"].map(_parse_frames)
    Y_h = np.array([[f in s for f in FRAMES] for s in hf], dtype=int)
    Y_m = np.array([[f in s for f in FRAMES] for s in mf], dtype=int)
    rep["frames_f1_micro"] = round(float(f1_score(Y_h, Y_m, average="micro", zero_division=0)), 3)
    rep["frames_f1_macro"] = round(float(f1_score(Y_h, Y_m, average="macro", zero_division=0)), 3)
    rep["frames_f1_per_label"] = {
        FRAMES[i]: round(float(f1_score(Y_h[:, i], Y_m[:, i], zero_division=0)), 3)
        for i in range(len(FRAMES))
    }

    val.mkdir(parents=True, exist_ok=True)
    (val / "agreement_report.json").write_text(json.dumps(rep, indent=2))
    print("  agreement report:")
    print(f"    stance kappa      {rep['stance_cohen_kappa']}  "
          f"(acc {rep['stance_accuracy']})")
    print(f"    score alpha       {rep['score_krippendorff_alpha']}  "
          f"(pearson {rep.get('score_pearson')})")
    print(f"    on_topic kappa    {rep['on_topic_cohen_kappa']}")
    print(f"    frames F1 micro   {rep['frames_f1_micro']} / macro {rep['frames_f1_macro']}")
    print(f"  -> {val/'agreement_report.json'}")
    return rep
