"""CLI orchestrator.

Stages write parquet to work_dir so the pipeline is resumable — a crash in
scoring never forces a re-ingest. Every stage also drops a provenance manifest.

    python -m ocpsg.pipeline ingest          --config config.yaml
    python -m ocpsg.pipeline dedup           --config config.yaml [--radius 3]
    python -m ocpsg.pipeline score           --config config.yaml [--limit N] [--yes]
    python -m ocpsg.pipeline stability       --config config.yaml [--n 100 --k 5]
    python -m ocpsg.pipeline embed           --config config.yaml
    python -m ocpsg.pipeline aggregate       --config config.yaml
    python -m ocpsg.pipeline drift           --config config.yaml
    python -m ocpsg.pipeline validate-export --config config.yaml [--n 300]
    python -m ocpsg.pipeline validate-agree  --config config.yaml
    python -m ocpsg.pipeline link            --config config.yaml
    python -m ocpsg.pipeline all             --config config.yaml [--limit N] [--yes]

Recommended order: ingest -> dedup -> score -> embed -> aggregate -> drift.
`dedup` is optional but cuts scoring cost. `score` prints a cost estimate and
waits for confirmation unless --yes. --limit caps segments for a cheap smoke
test. Validation is run separately once you've hand-labelled the gold set.
"""
from __future__ import annotations
import argparse
import asyncio
import glob
import os
from pathlib import Path

import pandas as pd
import yaml


def load_cfg(p: str) -> dict:
    with open(p) as f:
        return yaml.safe_load(f)


def workdir(cfg: dict) -> Path:
    return Path(os.path.expanduser(cfg["work_dir"]))


def _manifest(cfg, stage, args, extra=None):
    from .provenance import write_manifest
    write_manifest(workdir(cfg), cfg, stage, seed=getattr(args, "seed", 0),
                   hash_inputs=getattr(args, "hash_inputs", False), extra=extra)


def _load_segments(work: Path) -> pd.DataFrame:
    files = glob.glob(str(work / "segments" / "*" / "*.parquet"))
    if not files:
        raise SystemExit("No ingested segments. Run `ingest` first.")
    return pd.concat((pd.read_parquet(f) for f in files), ignore_index=True)


def _load_for_scoring(work: Path) -> pd.DataFrame:
    """Prefer dedup representatives if dedup has been run — that's the cost win."""
    rep = work / "segments_dedup" / "representatives.parquet"
    if rep.exists():
        print("  (scoring deduplicated representatives)")
        return pd.read_parquet(rep)
    return _load_segments(work)


def cmd_check(cfg, args):
    from .preflight import check_all
    check_all(cfg)


def cmd_profile(cfg, args):
    from .profile import profile_all
    profile_all(cfg, n=args.n)


def cmd_ingest(cfg, args):
    from .ingest import ingest_all
    stats = ingest_all(cfg)
    total = sum(s["segments_kept"] for s in stats)
    print(f"\nIngest complete: {total:,} segments across {len(stats)} sources.")
    for s in stats:
        print(f"  {s['source']:<20} kept={s['segments_kept']:>9,} "
              f"gated_out={s['segments_dropped_by_gate']:>9,}")
    _manifest(cfg, "ingest", args, extra={"sources": stats})


def cmd_dedup(cfg, args):
    from .dedup import run
    stats = run(workdir(cfg), radius=args.radius)
    _manifest(cfg, "dedup", args, extra=stats)


def _scoring_shard_files(work: Path):
    rep = work / "segments_dedup" / "representatives.parquet"
    if rep.exists():
        print("  (scoring deduplicated representatives)")
        return [rep]
    files = sorted(glob.glob(str(work / "segments" / "*" / "*.parquet")))
    if not files:
        raise SystemExit("No ingested segments. Run `ingest` first.")
    return files


_KEEP = ["segment_id", "document_id", "source", "tier", "jurisdiction",
         "year", "is_apex", "char_count"]


def _shard_records(d, preds):
    recs = []
    for r, p in zip(d.to_dict("records"), preds):
        fr = p.get("frames", [])
        rec = {k: r.get(k) for k in _KEEP}
        rec["stance"] = p.get("stance", "neutral")
        rec["score"] = float(p.get("score", 0.0))
        rec["frames"] = ",".join(fr) if isinstance(fr, (list, tuple)) else str(fr or "")
        rec["on_topic"] = bool(p.get("on_topic", False))
        rec["confidence"] = float(p.get("confidence", 0.0))
        rec["text"] = r.get("text")
        recs.append(rec)
    sd = pd.DataFrame(recs)
    sd["year"] = pd.array(sd["year"], dtype="Int64")
    sd["char_count"] = pd.array(sd["char_count"], dtype="Int64")
    sd["is_apex"] = sd["is_apex"].astype(bool)
    return sd


def _balanced_sample_ids(files, n, seed=0, focus=None, focus_weight=5.0):
    """Draw ~n segment_ids spread across sources. With `focus` (a set of source
    names), those sources are weighted up by focus_weight so a run concentrates
    effort where you want cells (e.g. EU legislation/caselaw), while still
    covering everything else. Reads only id+source columns, so it stays cheap."""
    import numpy as np
    meta = pd.concat([pd.read_parquet(f, columns=["segment_id", "source"])
                      for f in files], ignore_index=True)
    counts = meta["source"].value_counts()
    srcs = list(counts.index)
    focus = set(focus or [])
    eff = {s: float(counts[s]) * (focus_weight if s in focus else 1.0) for s in srcs}

    floor = max(1, n // (len(srcs) * 4))
    alloc = {s: min(floor, int(counts[s])) for s in srcs}
    remaining = n - sum(alloc.values())
    while remaining > 0:
        room = {s: int(counts[s]) - alloc[s] for s in srcs if int(counts[s]) - alloc[s] > 0}
        if not room:
            break
        tot = sum(eff[s] for s in room)
        added = 0
        for s in sorted(room, key=lambda x: -eff[x]):
            take = min(room[s], max(1, int(round(remaining * eff[s] / tot))), remaining - added)
            alloc[s] += take
            added += take
            if added >= remaining:
                break
        remaining -= added
        if added == 0:
            break

    rng = np.random.default_rng(seed)
    chosen = set()
    for s in srcs:
        pool = meta.loc[meta["source"] == s, "segment_id"].to_numpy()
        k = min(alloc[s], len(pool))
        if k:
            chosen.update(rng.choice(pool, size=k, replace=False).tolist())
    return chosen


def _done_ids(parts_dir, prior_scored):
    ids = set()
    import glob as _g
    for f in _g.glob(str(parts_dir / "*.parquet")):
        ids.update(pd.read_parquet(f, columns=["segment_id"])["segment_id"].tolist())
    if prior_scored.exists():
        ids.update(pd.read_parquet(prior_scored, columns=["segment_id"])["segment_id"].tolist())
    return ids


def _consolidate(parts_dir, scored_path):
    import glob as _g
    files = sorted(_g.glob(str(parts_dir / "*.parquet")))
    if not files:
        return 0
    allrows = pd.concat([pd.read_parquet(f) for f in files], ignore_index=True)
    allrows = allrows.drop_duplicates("segment_id")
    allrows.to_parquet(scored_path, index=False)
    return len(allrows)


def cmd_score(cfg, args):
    import time
    import shutil
    work = workdir(cfg)
    backend = cfg["stance"].get("backend", "nli")
    files = _scoring_shard_files(work)
    scored_path = work / "scored.parquet"
    parts_dir = work / "scored_parts"
    parts_dir.mkdir(parents=True, exist_ok=True)

    # reuse any prior scored.parquet so a bigger run only scores the delta
    if scored_path.exists() and not list(parts_dir.glob("*.parquet")):
        shutil.copy(scored_path, parts_dir / "part-00000.parquet")
    done = _done_ids(parts_dir, scored_path)
    if done:
        print(f"  resuming: {len(done):,} segments already scored (will be reused)")

    if backend in ("nli", "ollama"):
        from .stance_local import make_scorer
        print(f"Backend={backend} (local, no API, no key, no per-token cost). "
              f"Loading model (first run downloads it)...")
        scorer = make_scorer(cfg, backend)
    elif backend == "anthropic":
        print("Backend=anthropic (API). Ensure ANTHROPIC_API_KEY is set.")
        scorer = None
    else:
        raise SystemExit(f"unknown stance.backend {backend!r}")

    chosen = None
    if getattr(args, "sample", None):
        focus = [s.strip() for s in args.focus.split(",")] if getattr(args, "focus", None) else None
        chosen = _balanced_sample_ids(files, args.sample, getattr(args, "seed", 0),
                                      focus=focus, focus_weight=getattr(args, "focus_weight", 5.0))
        chosen = chosen - done
        fmsg = f" (focus: {focus}, x{args.focus_weight})" if focus else ""
        print(f"  balanced sample: {len(chosen):,} new segments to score{fmsg} "
              f"(target {args.sample:,}, {len(done):,} already done)")

    CHUNK = 500
    counter = len(list(parts_dir.glob("*.parquet")))
    scored_now, t0 = 0, time.time()
    stop = False
    for fp in files:
        if stop:
            break
        d = pd.read_parquet(fp)
        if chosen is not None:
            d = d[d["segment_id"].isin(chosen)]
        else:
            d = d[~d["segment_id"].isin(done)]
            if args.limit:
                d = d.head(max(0, args.limit - scored_now))
        if len(d) == 0:
            continue
        for i in range(0, len(d), CHUNK):
            chunk = d.iloc[i:i + CHUNK]
            if backend in ("nli", "ollama"):
                preds = scorer(chunk.to_dict("records"))
                sd = _shard_records(chunk, preds)
            else:
                from .stance import score_frame
                import asyncio
                sdf = asyncio.run(score_frame(chunk, cfg, work))
                m = chunk[["segment_id", "text"]].merge(sdf, on="segment_id", how="inner")
                sd = _shard_records(m, m[["stance", "score", "frames",
                                          "on_topic", "confidence"]].to_dict("records"))
            sd.to_parquet(parts_dir / f"part-{counter:05d}.parquet", index=False)
            counter += 1
            scored_now += len(sd)
            print(f"  scored +{scored_now:,} new  ({scored_now/max(1e-9, time.time()-t0):.1f}/s)")
            if args.limit and chosen is None and scored_now >= args.limit:
                stop = True
                break

    n = _consolidate(parts_dir, scored_path)
    print(f"Scored this run: {scored_now:,} new. Total on disk: {n:,} -> {scored_path}")
    _manifest(cfg, "score", args, extra={"backend": backend,
                                         "new_this_run": scored_now, "total": n})


def cmd_stability(cfg, args):
    backend = cfg["stance"].get("backend", "nli")
    if backend == "nli":
        print("NLI backend is deterministic - no self-inconsistency to measure. "
              "Stability applies to sampling backends (anthropic/ollama).")
        return
    from .stance import score_stability
    work = workdir(cfg)
    df = _load_for_scoring(work)
    asyncio.run(score_stability(df, cfg, work, n_segments=args.n, k=args.k))
    _manifest(cfg, "stability", args)


def cmd_embed(cfg, args):
    from .embed import embed_segments
    work = workdir(cfg)
    embed_segments(pd.read_parquet(work / "scored.parquet"), cfg, work)
    _manifest(cfg, "embed", args)


def cmd_aggregate(cfg, args):
    from .aggregate import run
    work = workdir(cfg)
    if getattr(args, "min_cell", None):
        cfg["aggregate"]["min_segments_per_cell"] = args.min_cell
        print(f"  min_segments_per_cell = {args.min_cell} (override)")
    run(pd.read_parquet(work / "scored.parquet"), cfg, work)
    _manifest(cfg, "aggregate", args)


def cmd_drift(cfg, args):
    from .drift import track_drift
    track_drift(cfg, workdir(cfg))
    _manifest(cfg, "drift", args)


def cmd_gold_build(cfg, args):
    from .gold import build_gold_set
    build_gold_set(workdir(cfg), n=args.n, seed=args.seed)


def cmd_validate_export(cfg, args):
    from .validate import export_gold_sample
    export_gold_sample(workdir(cfg), n=args.n, seed=args.seed)


def cmd_validate_agree(cfg, args):
    from .validate import compute_agreement
    compute_agreement(workdir(cfg), gold_csv=args.gold)


def cmd_link(cfg, args):
    from .linkage import link
    link(workdir(cfg))
    _manifest(cfg, "link", args)


def cmd_all(cfg, args):
    cmd_ingest(cfg, args)
    cmd_dedup(cfg, args)
    cmd_score(cfg, args)
    cmd_embed(cfg, args)
    cmd_aggregate(cfg, args)
    cmd_drift(cfg, args)
    cmd_link(cfg, args)


CMDS = {"check": cmd_check, "profile": cmd_profile, "ingest": cmd_ingest,
        "dedup": cmd_dedup, "score": cmd_score,
        "stability": cmd_stability, "embed": cmd_embed, "aggregate": cmd_aggregate,
        "drift": cmd_drift, "gold-build": cmd_gold_build,
        "validate-export": cmd_validate_export,
        "validate-agree": cmd_validate_agree, "link": cmd_link, "all": cmd_all}


def main():
    ap = argparse.ArgumentParser(prog="ocpsg.pipeline")
    ap.add_argument("command", choices=CMDS)
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--limit", type=int, default=None)
    ap.add_argument("--sample", type=int, default=None,
                    help="score a balanced sample of N segments across all sources")
    ap.add_argument("--model", choices=["xsmall", "base", "large"], default=None,
                    help="NLI speed/accuracy tier for this run (overrides config)")
    ap.add_argument("--focus", default=None,
                    help="comma-separated source names to oversample, e.g. "
                         "eurlex_legislation,eurlex_caselaw")
    ap.add_argument("--focus-weight", type=float, default=5.0,
                    help="how strongly to oversample --focus sources (default 5x)")
    ap.add_argument("--min-cell", type=int, default=None,
                    help="override min_segments_per_cell for aggregate (default 5)")
    ap.add_argument("--yes", action="store_true", help="skip the cost-gate prompt")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--radius", type=int, default=3, help="dedup Hamming radius")
    ap.add_argument("--n", type=int, default=300, help="sample size (validate/stability)")
    ap.add_argument("--k", type=int, default=5, help="stability repeats per segment")
    ap.add_argument("--hash-inputs", action="store_true",
                    help="sha256 the corpus files in the manifest (slow)")
    ap.add_argument("--gold", default=None,
                    help="path to an external gold CSV for validate-agree")
    args = ap.parse_args()
    cfg = load_cfg(args.config)
    if getattr(args, "model", None):
        tiers = {
            "xsmall": "MoritzLaurer/deberta-v3-xsmall-zeroshot-v1.1-all-33",
            "base": "MoritzLaurer/deberta-v3-base-zeroshot-v2.0",
            "large": "MoritzLaurer/deberta-v3-large-zeroshot-v2.0",
        }
        cfg["stance"]["nli_model"] = tiers[args.model]
    CMDS[args.command](cfg, args)


if __name__ == "__main__":
    main()
