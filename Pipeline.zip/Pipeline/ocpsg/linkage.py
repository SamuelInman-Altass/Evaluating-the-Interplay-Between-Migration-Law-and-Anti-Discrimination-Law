"""Linkage to Section V outcome indicators.

You haven't supplied the outcome data yet (complaints, enforcement rates, case
outcomes, labour-market participation), so this is the *interface* it plugs
into, not a guess at numbers. Drop a CSV matching OUTCOME_SCHEMA at
work_dir/outcomes.csv and this merges it onto P(j,y,t) and the gap series and
runs the H1-H5 correlations from slide 13.

OUTCOME_SCHEMA (one row per jurisdiction-year):
    jurisdiction, year, complaints, enforcement_actions, case_win_rate,
    labour_participation_gap
Add columns freely; the correlation step uses whatever numeric columns exist.
"""
from __future__ import annotations
from pathlib import Path

import pandas as pd

OUTCOME_SCHEMA = ["jurisdiction", "year", "complaints", "enforcement_actions",
                  "case_win_rate", "labour_participation_gap"]


def link(work_dir: Path) -> pd.DataFrame | None:
    idx_dir = work_dir / "indices"
    oc_path = work_dir / "outcomes.csv"
    if not oc_path.exists():
        print(f"  [linkage] no outcomes.csv at {oc_path} — skipping. "
              f"Expected columns: {OUTCOME_SCHEMA}")
        return None
    outcomes = pd.read_csv(oc_path)
    pj = pd.read_parquet(idx_dir / "protectiveness_index.parquet")
    # pivot tiers to columns so each (j,y) has P_legislative, P_guidance, ...
    wide = pj.pivot_table(index=["jurisdiction", "year"], columns="tier",
                          values="P").add_prefix("P_").reset_index()
    gap = pd.read_parquet(idx_dir / "implementation_gap.parquet")
    merged = wide.merge(gap, on=["jurisdiction", "year"], how="outer") \
                 .merge(outcomes, on=["jurisdiction", "year"], how="left")
    merged.to_csv(idx_dir / "linked_panel.csv", index=False)

    num = merged.select_dtypes("number")
    corr = num.corr(method="spearman")
    corr.to_csv(idx_dir / "linkage_correlations.csv")
    print(f"  [linkage] panel + Spearman correlations -> {idx_dir}")
    return merged
