"""Near/exact-duplicate collapse - memory-safe, streaming.

Legal corpora repeat verbatim: standard recitals across amended regulations,
reissued guidance, block-quoted judgments. Scoring each copy wastes compute and
biases a P(j,y,t) cell toward whatever boilerplate repeats most.

This streams the ingested shards one at a time and collapses EXACT text
duplicates (after lowercasing/whitespace-normalising), keeping one representative
per unique text and recording a dup_count. It never loads the whole corpus into
memory - only a dict of text hashes (tens of MB even for ~1M segments) - so it
runs comfortably on a laptop. `score` then scores only the representatives.

This is optional. Skipping it just means scoring some duplicates.
"""
from __future__ import annotations
from pathlib import Path
import glob
import hashlib

import pandas as pd


def _texthash(t: str) -> str:
    return hashlib.blake2b((t or "").strip().lower().encode("utf-8", "ignore"),
                           digest_size=16).hexdigest()


def run(work_dir: Path, radius: int = 0) -> dict:
    import pyarrow as pa
    import pyarrow.parquet as pq

    files = sorted(glob.glob(str(work_dir / "segments" / "*" / "*.parquet")))
    if not files:
        raise SystemExit("No ingested segments. Run `ingest` first.")
    out = work_dir / "segments_dedup"
    out.mkdir(parents=True, exist_ok=True)

    seen: dict[str, str] = {}       # text hash -> representative segment_id
    counts: dict[str, int] = {}     # representative segment_id -> dup count
    dup_rows = []                   # (segment_id, dup_group, is_dup_rep)
    n0, nrep = 0, 0
    writer = None

    for f in files:
        d = pd.read_parquet(f)
        n0 += len(d)
        keep = []
        for sid, txt in zip(d["segment_id"].tolist(), d["text"].tolist()):
            h = _texthash(txt)
            rep = seen.get(h)
            if rep is None:
                seen[h] = sid
                counts[sid] = 1
                dup_rows.append((sid, sid, True))
                keep.append(True)
            else:
                counts[rep] += 1
                dup_rows.append((sid, rep, False))
                keep.append(False)
        reps = d[pd.Series(keep, index=d.index)]
        if len(reps):
            table = pa.Table.from_pandas(reps, preserve_index=False)
            if writer is None:
                writer = pq.ParquetWriter(out / "representatives.parquet", table.schema)
            writer.write_table(table)
            nrep += len(reps)
    if writer:
        writer.close()

    dm = pd.DataFrame(dup_rows, columns=["segment_id", "dup_group", "is_dup_rep"])
    dm["dup_count"] = dm["dup_group"].map(counts).fillna(1).astype(int)
    dm.to_parquet(out / "dup_map.parquet", index=False)

    stats = {"segments_in": n0, "representatives": int(nrep),
             "duplicates_removed": int(n0 - nrep),
             "reduction_pct": round(100 * (1 - nrep / n0), 1) if n0 else 0.0}
    print(f"  dedup: {n0:,} -> {nrep:,} unique "
          f"({stats['reduction_pct']}% removed) -> {out}")
    return stats
