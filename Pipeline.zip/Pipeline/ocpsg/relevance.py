"""Relevance gate.

Reproduces the deck's three collection clusters (Clothing, Time, Migration
Status) and adds an explicit Religion cluster, because the project's subject is
religion x migration but several sources (notably the 4 GB EUR-Lex caselaw dump)
were pulled without that filter. `gate` sources must match >=1 cluster to
survive; `keep` sources pass through untouched.

This is deliberately a cheap lexical gate, not the model. Its only job is to
stop you paying LLM tokens on milk-levy and customs judgments. Recall is
favoured over precision (better to score a few off-topic segments than to drop
a borderline religious-accommodation passage). The false-positive *Re L* class
of error — a child-death case tagged "Clothing" purely on the token "veil" — is
handled downstream by the model's `on_topic` flag, not here.
"""
from __future__ import annotations
import re

CLUSTERS: dict[str, list[str]] = {
    "Clothing": [
        "headscarf", "hijab", "niqab", "burqa", "veil", "face veil", "turban",
        "kippah", "yarmulke", "crucifix", "religious dress", "religious symbol",
        "religious garment", "skullcap", "jilbab", "khimar",
    ],
    "Time": [
        "sabbath", "prayer time", "friday prayer", "religious holiday",
        "religious observance", "fasting", "ramadan", "day of rest",
        "time off for", "working time", "shift swap", "rest day",
    ],
    "MigrationStatus": [
        "indefinite leave", "leave to remain", "no recourse to public funds",
        "right to work", "right to rent", "asylum", "refugee", "deportation",
        "removal", "sponsor", "settlement", "immigration rules", "visa",
        "subsidiary protection", "credibility", "persecution", "hostile environment",
    ],
    "Religion": [
        "religion", "religious", "belief", "faith", "manifest", "conscience",
        "muslim", "christian", "jewish", "sikh", "hindu", "convert", "apostasy",
        "proselyt", "discrimination on grounds of religion", "freedom of religion",
        "article 9", "article 10 of the charter", "place of worship",
    ],
}

_COMPILED = {
    name: re.compile(r"\b(?:%s)" % "|".join(re.escape(t) for t in terms), re.I)
    for name, terms in CLUSTERS.items()
}


def matched_clusters(text: str) -> list[str]:
    if not text:
        return []
    return [name for name, rx in _COMPILED.items() if rx.search(text)]


def passes(text: str, policy: str) -> tuple[bool, list[str]]:
    """Return (keep?, matched_cluster_names)."""
    hits = matched_clusters(text)
    if policy == "keep":
        return True, hits
    if policy == "gate":
        return (len(hits) > 0), hits
    raise ValueError(f"unknown relevance policy {policy!r}")
