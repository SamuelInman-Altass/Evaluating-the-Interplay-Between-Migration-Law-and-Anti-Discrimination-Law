"""Per-source adapters.

Each adapter extracts the source-specific bits (text, id, court/citation) and
then defers tier / jurisdiction / year / apex / referring-country to derive.py,
which reads them off the record. The tier and jurisdiction passed in from config
are only fallbacks used when the data is silent. So adding a new corpus =
identifying its text and id fields; the classification metadata derives itself.

Every adapter is defensive: missing keys default rather than raise, so one
malformed record never kills a multi-hour ingest.
"""
from __future__ import annotations
from typing import Iterator
import re

from .schema import Segment, make_segment_id
from .segment import split_document
from .derive import derive_all


def _seg(rec, order, source, tier_default, jur_default, *, doc_id, court,
         citation, source_url, segment_type, text, seg_id=None,
         cluster_labels="", matched_keywords="") -> Segment:
    """Build a Segment, deriving tier/jurisdiction/year/apex from the record."""
    d = derive_all(rec, tier_default=tier_default, jur_default=jur_default, court=court)
    return Segment(
        segment_id=seg_id or make_segment_id(doc_id, order), document_id=str(doc_id),
        source=source, tier=d["tier"], jurisdiction=d["jurisdiction"], year=d["year"],
        court=court, citation=citation, source_url=source_url,
        segment_type=segment_type, is_apex=d["is_apex"],
        referring_country=d["referring_country"], text=text,
        cluster_labels=cluster_labels or "", matched_keywords=matched_keywords or "",
    )


# --------------------------------------------------------------------------- #
# Whole-document sources
# --------------------------------------------------------------------------- #
def adapt_hansard(rec, source, tier, jur) -> Iterator[Segment]:
    doc_id = rec.get("source_url") or rec.get("neutral_citation") or "hansard_unknown"
    for i, chunk in enumerate(split_document(rec.get("full_text", ""))):
        yield _seg(rec, i, source, tier, jur, doc_id=doc_id, court=rec.get("court", ""),
                   citation=rec.get("neutral_citation", ""),
                   source_url=rec.get("source_url", ""), segment_type="speech_turn",
                   text=chunk, cluster_labels=rec.get("cluster_labels", ""),
                   matched_keywords=rec.get("all_matched_keywords", ""))


def adapt_uk_caselaw(rec, source, tier, jur) -> Iterator[Segment]:
    doc_id = rec.get("case_id") or rec.get("neutral_citation") or rec.get("source_url")
    court = rec.get("court", "")
    blocks: list[tuple[str, str]] = []
    if rec.get("text_reasoning"):
        for stype in ("text_facts", "text_reasoning", "text_holding"):
            if rec.get(stype):
                for chunk in split_document(rec[stype]):
                    blocks.append((stype.replace("text_", ""), chunk))
    else:
        for chunk in split_document(rec.get("full_text", "")):
            blocks.append(("paragraph", chunk))
    for i, (stype, chunk) in enumerate(blocks):
        yield _seg(rec, i, source, tier, jur, doc_id=doc_id, court=court,
                   citation=rec.get("neutral_citation", ""),
                   source_url=rec.get("source_url", ""), segment_type=stype,
                   text=chunk, cluster_labels=rec.get("cluster_labels", ""))


def adapt_uk_legislation(rec, source, tier, jur) -> Iterator[Segment]:
    import re
    doc_id = rec.get("source_url") or rec.get("neutral_citation") or "ukleg_unknown"
    act = rec.get("court", "")            # this source overloads `court` with the Act title
    for i, chunk in enumerate(split_document(rec.get("full_text", ""))):
        stype = "recital" if re.match(r"\s*(whereas|recital)", chunk, re.I) else "operative"
        yield _seg(rec, i, source, tier, jur, doc_id=doc_id, court=act,
                   citation=rec.get("neutral_citation", ""),
                   source_url=rec.get("source_url", ""), segment_type=stype,
                   text=chunk, cluster_labels=rec.get("cluster_labels", ""),
                   matched_keywords=rec.get("all_matched_keywords", ""))


# --------------------------------------------------------------------------- #
# Pre-segmented sources (one record == one segment)
# --------------------------------------------------------------------------- #
def adapt_eurlex_legislation(rec, source, tier, jur) -> Iterator[Segment]:
    doc_id = rec.get("celex") or rec.get("eli") or rec.get("source_url")
    yield _seg(rec, rec.get("segment_order", 0), source, tier, jur, doc_id=doc_id,
               court=rec.get("title", ""), citation=rec.get("celex", ""),
               source_url=rec.get("source_url", ""),
               segment_type=rec.get("segment_type", ""), text=rec.get("segment_text", ""))


def adapt_eurlex_caselaw(rec, source, tier, jur) -> Iterator[Segment]:
    doc_id = rec.get("celex") or rec.get("ecli") or rec.get("source_url")
    court = rec.get("court_chamber") or "Court of Justice"
    yield _seg(rec, rec.get("segment_order", 0), source, tier, jur, doc_id=doc_id,
               court=court, citation=rec.get("ecli", ""),
               source_url=rec.get("source_url", ""),
               segment_type=rec.get("segment_type", ""), text=rec.get("segment_text", ""))


def adapt_fra_caselaw(rec, source, tier, jur) -> Iterator[Segment]:
    doc_id = rec.get("document_id") or rec.get("ecli") or rec.get("source_url")
    yield _seg(rec, rec.get("segment_order", 0), source, tier, jur, doc_id=doc_id,
               court=rec.get("deciding_body", ""), citation=rec.get("ecli", ""),
               source_url=rec.get("source_url", ""),
               segment_type=rec.get("segment_type", ""), text=rec.get("text", ""),
               seg_id=rec.get("segment_id"))


def adapt_govuk_guidance(rec, source, tier, jur) -> Iterator[Segment]:
    doc_id = rec.get("content_id") or rec.get("govuk_url")
    orgs = rec.get("organisations") or []
    yield _seg(rec, rec.get("segment_order", 0), source, tier, jur, doc_id=doc_id,
               court=(orgs[0] if orgs else ""), citation=rec.get("title", ""),
               source_url=rec.get("govuk_url", ""),
               segment_type=rec.get("segment_type", "guidance_section"),
               text=rec.get("segment_text", ""))


def _ecthr_respondent(case_name: str) -> str | None:
    """'CASE OF JURIC v. CROATIA' -> 'Croatia'; 'A.V. AND OTHERS v. GERMANY' ->
    'Germany' (split on the LAST versus so applicant initials like 'A.V.' are not
    mistaken for the separator)."""
    if not case_name:
        return None
    parts = re.split(r"\s+v\.?\s+", case_name, flags=re.I)
    if len(parts) < 2:
        return None
    resp = parts[-1].strip().strip('"')
    resp = re.sub(r"\s*\(.*$", "", resp).strip()      # drop "(No. 2)" etc
    resp = re.sub(r"^THE\s+", "", resp, flags=re.I).strip()
    return resp.title().strip() or None


def adapt_hudoc(rec, source, tier, jur) -> Iterator[Segment]:
    """ECtHR HUDOC export. Real schema: nested dicts `citation` (case_name,
    application_no, date) and `texts` (raw judgment), plus a pre-extracted
    `proportionality_excerpts` list, which is high-signal doctrinal material and
    is emitted as its own segment type."""
    cit = rec.get("citation") or {}
    texts = rec.get("texts") or {}
    doc_id = str(rec.get("id") or cit.get("application_no") or "hudoc_unknown")
    respondent = _ecthr_respondent(cit.get("case_name", "")) or \
        (jur if jur and jur != "ECtHR" else "ECtHR")
    yr = None
    m = re.search(r"(19|20)\d{2}", str(cit.get("date") or cit.get("year") or ""))
    if m:
        yr = int(m.group(0))
    tier = tier or "adjudicative"
    appno = cit.get("application_no", "")
    court = "European Court of Human Rights"

    order = 0
    for ex in rec.get("proportionality_excerpts") or []:
        txt = (ex or {}).get("excerpt", "")
        if txt and len(txt) >= 40:
            yield Segment(segment_id=make_segment_id(doc_id, order), document_id=doc_id,
                          source=source, tier=tier, jurisdiction=respondent, year=yr,
                          court=court, citation=appno, source_url="",
                          segment_type="proportionality_excerpt", is_apex=True, text=txt)
            order += 1

    body = texts.get("raw") or texts.get("judgment") or texts.get("facts") or ""
    for chunk in split_document(body):
        yield Segment(segment_id=make_segment_id(doc_id, order), document_id=doc_id,
                      source=source, tier=tier, jurisdiction=respondent, year=yr,
                      court=court, citation=appno, source_url="",
                      segment_type="judgment_paragraph", is_apex=True, text=chunk)
        order += 1


ADAPTERS = {
    "hansard": adapt_hansard,
    "uk_caselaw": adapt_uk_caselaw,
    "uk_legislation": adapt_uk_legislation,
    "eurlex_legislation": adapt_eurlex_legislation,
    "eurlex_caselaw": adapt_eurlex_caselaw,
    "fra_caselaw": adapt_fra_caselaw,
    "govuk_guidance": adapt_govuk_guidance,
    "hudoc": adapt_hudoc,
}

# candidate keys, exposed so `profile` can report which fields exist per source
ADAPTER_FIELDS = {
    "text": ["full_text", "segment_text", "text", "texts", "text_reasoning", "body"],
    "id": ["case_id", "celex", "document_id", "content_id", "itemid", "id", "appno",
           "neutral_citation", "source_url"],
    "date": list(("judgment_year", "decision_date", "date_document", "judgment_date",
                  "public_updated_at", "judgmentdate")),
    "jurisdiction": ["country", "respondent", "referring_court_country"],
    "tier_signal": ["deciding_body_type", "document_form", "document_type", "type"],
}
