"""Preflight: confirm the config maps onto what is actually on disk.

Run this first, right after pointing base_dir at your Downloads. For each source
it checks the file exists, reports its size, detects JSON-array vs JSON-lines,
reads the first record, runs the adapter on it to confirm at least one non-empty
segment comes out, and shows what tier/jurisdiction/apex were derived from that
record. It also lists any .json files sitting in the source folders that the
config does NOT reference, so nothing is silently left out (or double-counted).

Reads one record per file, so it is effectively instant even on the 4 GB file.

    python -m ocpsg.pipeline check --config config.yaml
"""
from __future__ import annotations
from pathlib import Path
import json
import os

from .ingest import _iter_records
from .adapters import ADAPTERS, ADAPTER_FIELDS
from .derive import derive_all


def _sniff_format(path: Path) -> str:
    with open(path, "rb") as f:
        b = f.read(1)
        while b and b.isspace():
            b = f.read(1)
    return {b"[": "json-array", b"{": "json-lines/object"}.get(b, "unknown")


def _human(nbytes: int) -> str:
    x = float(nbytes)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if x < 1024 or unit == "TB":
            return f"{x:.1f} {unit}"
        x /= 1024


def check_source(src: dict, base_dir: Path) -> dict:
    path = base_dir / src["path"]
    row = {"source": src["name"], "path": str(path), "adapter": src["adapter"],
           "relevance": src["relevance"]}
    if not path.exists():
        row["status"] = "MISSING"
        return row
    row["size"] = _human(path.stat().st_size)
    row["format"] = _sniff_format(path)
    try:
        rec = next(_iter_records(path, src.get("records_key")))
    except StopIteration:
        row["status"] = "EMPTY_FILE"
        return row
    except Exception as e:
        row["status"] = f"READ_ERROR: {e}"
        return row

    # which expected field roles are present in the first record
    found = {role: [k for k in keys if rec.get(k) not in (None, "", [])]
             for role, keys in ADAPTER_FIELDS.items()}
    row["fields_found"] = {r: v for r, v in found.items() if v}
    row["missing_field_roles"] = [r for r, v in found.items() if not v]

    segs = list(ADAPTERS[src["adapter"]](rec, src["name"], src.get("tier"),
                                         src.get("jurisdiction")))
    if not segs:
        row["status"] = "ADAPTER_YIELDED_NOTHING"
        return row
    s0 = segs[0]
    row["status"] = "OK" if s0.text else "FIRST_SEGMENT_EMPTY"
    row["first_record_derived"] = {
        "tier": s0.tier, "jurisdiction": s0.jurisdiction, "year": s0.year,
        "is_apex": s0.is_apex, "segments_from_record_1": len(segs),
    }
    return row


def check_all(cfg: dict) -> list[dict]:
    base = Path(os.path.expanduser(cfg["base_dir"]))
    referenced, rows = set(), []
    for src in cfg["sources"]:
        rows.append(check_source(src, base))
        referenced.add((base / src["path"]).resolve())

    # any .json in the referenced folders that config does not use
    folders = {(base / s["path"]).parent for s in cfg["sources"]}
    extra = sorted({str(f) for folder in folders if folder.exists()
                    for f in folder.glob("*.json")
                    if f.resolve() not in referenced})

    print(f"\nbase_dir: {base}")
    ok = sum(r.get("status") == "OK" for r in rows)
    print(f"sources: {ok}/{len(rows)} ready\n")
    for r in rows:
        mark = "OK " if r.get("status") == "OK" else "!! "
        head = f"  {mark}{r['source']:<18}"
        if r.get("status") != "OK":
            print(f"{head} {r['status']}   ({r['path']})")
            continue
        d = r["first_record_derived"]
        print(f"{head} {r['size']:>9}  {r['format']:<16} "
              f"tier={d['tier']:<12} jur={d['jurisdiction']:<10} apex={d['is_apex']}")
        if r["missing_field_roles"]:
            print(f"       missing field roles: {r['missing_field_roles']}")
    if extra:
        print("\n  files present but NOT in config (intentional? check config):")
        for f in extra:
            print(f"    - {f}")

    work = Path(os.path.expanduser(cfg["work_dir"]))
    work.mkdir(parents=True, exist_ok=True)
    (work / "check.json").write_text(json.dumps(
        {"sources": rows, "unreferenced_json": extra}, indent=2))
    print(f"\n  full report -> {work/'check.json'}")
    return rows
