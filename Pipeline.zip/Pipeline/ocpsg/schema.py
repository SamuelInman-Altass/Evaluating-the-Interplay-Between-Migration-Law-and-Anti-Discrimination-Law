"""The one schema every source is normalised into.

Every adapter yields dicts with these keys. Downstream stages only ever see
this shape, so adding a new corpus = writing one adapter, nothing else.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict, field
from typing import Optional
import hashlib

TIERS = {"legislative", "deliberative", "adjudicative", "guidance"}

# Doctrinal frames from the normative-tension matrix (deck slide 6).
# Multi-label: a segment can carry several. Order is fixed so the LLM and the
# parser agree on the label set.
FRAMES = [
    "manifestation",            # religion as a right to be exercised
    "dignity_pluralism",        # minority presence as part of democratic order
    "indirect_discrimination",  # neutral rule, group-specific burden
    "strict_scrutiny",          # interference needs weighty justification
    "access_to_remedies",       # complaint / enforcement channels as protection
    "integration_cohesion",     # protection conditional on fitting norms
    "neutrality_corporate",     # religious visibility as operational disruption
    "public_order_border",      # status/border control over equal treatment
    "proportionality_balancing",# claim absorbed into managerial/state interest
    "compliance_audit",         # frontline actors incentivised to avoid risk
]

# "Apex" courts get weighted into the FORMAL side of the implementation-gap
# statistic (deck slide 8). Matched case-insensitively as substrings of `court`.
APEX_COURT_MARKERS = [
    "supreme court", "uksc", "house of lords", "ukhl",
    "court of appeal", "ewca",
    "court of justice", "cjeu", "court of first instance", "general court",
    "european court of human rights", "ecthr", "grand chamber",
    "constitutional court",
]


@dataclass
class Segment:
    # identity
    segment_id: str
    document_id: str
    source: str              # registry name, e.g. "eurlex_caselaw"
    # placement in the protectiveness cube
    tier: str                # one of TIERS
    jurisdiction: str        # UK | EU | ECtHR | <country>
    year: Optional[int]
    # provenance
    court: str = ""          # court / act title / debate chamber / guidance org
    citation: str = ""
    source_url: str = ""
    segment_type: str = ""   # recital | operative | holding | speech_turn | ...
    is_apex: bool = False
    referring_country: str = ""   # EU preliminary references: origin member state
    # content
    text: str = ""
    char_count: int = 0
    # collection-time keyword metadata (may be empty)
    cluster_labels: str = ""
    matched_keywords: str = ""

    def __post_init__(self):
        if not self.char_count:
            self.char_count = len(self.text or "")
        if self.tier not in TIERS:
            raise ValueError(f"bad tier {self.tier!r} for {self.segment_id}")

    def to_row(self) -> dict:
        return asdict(self)


def make_segment_id(document_id: str, order: int) -> str:
    h = hashlib.sha1(f"{document_id}::{order}".encode()).hexdigest()[:16]
    return f"{document_id}:{order}:{h}"


def detect_apex(court: str) -> bool:
    c = (court or "").lower()
    return any(m in c for m in APEX_COURT_MARKERS)
