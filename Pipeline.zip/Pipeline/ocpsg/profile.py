"""Profile the corpus: show what the pipeline derives from the actual data.

Because tier / jurisdiction / apex are now read off each record, you want to see
what that produced before committing to a full run - especially for HUDOC, whose
field names vary across exports. This samples the first N records of every file
and reports, per source: which expected fields are present, the derived tier and
jurisdiction distributions, the year range, the apex rate, and what fraction
would survive the relevance gate. Cheap (streams only N records) and read-only.

    python -m ocpsg.pipeline profile --config config.yaml [--n 500]
"""
from __future__ import annotations
from pathlib import Path
from collections import Counter
import json
import os

from .ingest import _iter_records
from .adapters import ADAPTERS, ADAPTER_FIELDS
from .relevance import passes


def _field_coverage(sample_recs: list[dict]) -> dict:
    out = {}
    for role, keys in ADAPTER_FIELDS.items():
        present = {k: sum(1 for r in sample_recs if r.get(k) not in (None, "", []))
                   for k in keys}
        present = {k: v for k, v in present.items() if v}
        out[role] = present or {"<none found>": 0}
    return out


def profile_source(src: dict, base_dir: Path, n: int = 500) -> dict:
    path = base_dir / src["path"]
    if not path.exists():
        return {"source": src["name"], "error": f"file not found: {path}"}
    adapter = ADAPTERS[src["adapter"]]

    raw, tiers, jurs, years, apex, kept, segs = [], Counter(), Counter(), [], 0, 0, 0
    for i, rec in enumerate(_iter_records(path, src.get("records_key"))):
        if i >= n:
            break
        raw.append(rec)
        for seg in adapter(rec, src["name"], src.get("tier"), src.get("jurisdiction")):
            segs += 1
            tiers[seg.tier] += 1
            jurs[seg.jurisdiction] += 1
            apex += int(seg.is_apex)
            if seg.year:
                years.append(seg.year)
            keep, _ = passes(seg.text, src["relevance"])
            kept += int(keep)

    return {
        "source": src["name"],
        "records_sampled": len(raw),
        "segments_from_sample": segs,
        "field_coverage": _field_coverage(raw),
        "derived_tier": dict(tiers),
        "derived_jurisdiction": dict(jurs.most_common(10)),
        "year_range": [min(years), max(years)] if years else None,
        "apex_rate": round(apex / segs, 3) if segs else None,
        "gate_keep_rate": round(kept / segs, 3) if segs else None,
        "relevance_policy": src["relevance"],
        "config_fallbacks": {"tier": src.get("tier"), "jurisdiction": src.get("jurisdiction")},
    }


def profile_all(cfg: dict, n: int = 500) -> list[dict]:
    base = Path(os.path.expanduser(cfg["base_dir"]))
    work = Path(os.path.expanduser(cfg["work_dir"]))
    work.mkdir(parents=True, exist_ok=True)
    reports = []
    for src in cfg["sources"]:
        rep = profile_source(src, base, n=n)
        reports.append(rep)
        if "error" in rep:
            print(f"  [skip] {rep['source']}: {rep['error']}")
            continue
        print(f"\n=== {rep['source']} ({rep['records_sampled']} recs sampled) ===")
        print(f"  derived tier:         {rep['derived_tier']}")
        print(f"  derived jurisdiction: {rep['derived_jurisdiction']}")
        print(f"  year range:           {rep['year_range']}   apex rate: {rep['apex_rate']}")
        print(f"  gate keep-rate:       {rep['gate_keep_rate']}  (policy={rep['relevance_policy']})")
        tx = rep["field_coverage"]["text"]
        idf = rep["field_coverage"]["id"]
        print(f"  text field(s):        {list(tx)}")
        print(f"  id field(s):          {list(idf)}")
    (work / "profile.json").write_text(json.dumps(reports, indent=2))
    print(f"\n  full profile -> {work/'profile.json'}")
    return reports
