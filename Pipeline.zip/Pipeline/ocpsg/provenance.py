"""Run provenance.

The first question a reviewer asks is "which corpus, which prompt, which model
produced this figure?" This records that for every stage: a timestamped JSON
manifest capturing the config snapshot, model + embeddings model, the stance
PROMPT_VERSION, the RNG seed, package version, and a sha256 of each input file
(streamed, so hashing the 4 GB file doesn't blow memory) with row counts.

Hashing 9.6 GB takes a few minutes; pass hash_inputs=False to skip during quick
iterations, True for the run that goes in the paper.
"""
from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os

from . import __version__
from .stance import PROMPT_VERSION


def _sha256(path: Path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(chunk), b""):
            h.update(block)
    return h.hexdigest()


def write_manifest(work_dir: Path, cfg: dict, stage: str,
                   seed: int = 0, hash_inputs: bool = False,
                   extra: dict | None = None) -> Path:
    base = Path(os.path.expanduser(cfg["base_dir"]))
    inputs = []
    for src in cfg["sources"]:
        p = base / src["path"]
        rec = {"name": src["name"], "path": str(p), "exists": p.exists()}
        if p.exists():
            rec["size_bytes"] = p.stat().st_size
            if hash_inputs:
                rec["sha256"] = _sha256(p)
        inputs.append(rec)

    manifest = {
        "stage": stage,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "package_version": __version__,
        "prompt_version": PROMPT_VERSION,
        "seed": seed,
        "stance_model": cfg["stance"]["model"],
        "embeddings_model": cfg["embeddings"]["model"],
        "config": cfg,
        "inputs": inputs,
    }
    if extra:
        manifest["stage_stats"] = extra

    out = work_dir / "manifests"
    out.mkdir(parents=True, exist_ok=True)
    ts = manifest["timestamp_utc"].replace(":", "").replace("-", "")[:15]
    path = out / f"{stage}-{ts}.json"
    path.write_text(json.dumps(manifest, indent=2))
    print(f"  manifest -> {path}")
    return path
