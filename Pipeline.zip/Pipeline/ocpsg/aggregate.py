"""Aggregation (deck steps 5-6 + slide 12 + slide 8).

Protectiveness index:
    P(j, y, t) = weighted mean segment score | jurisdiction j, year y, tier t
weighting each segment by  confidence / (segments in its document)  so that one
long judgment cannot dominate a cell (the deck's "document-family structure"
control) and low-confidence model outputs count less.

Off-topic segments (model on_topic == False) are dropped here — this is where
the Re L "veil"-false-positive class is removed, after the model has judged it,
not by keyword guesswork.

Uncertainty is a CLUSTER bootstrap: we resample whole documents (not segments),
because segments within a judgment are not independent. Cells thinner than
min_segments_per_cell are suppressed.

Implementation-gap statistic (slide 8):
    gap(j, y) = mean P(FORMAL) - mean P(OPERATIONAL)
where FORMAL = legislative + apex adjudicative, OPERATIONAL = guidance +
enforcement-facing instruments. A widening gap = protective formal law sitting
above restrictive operational practice, the project's core diagnostic.
"""
from __future__ import annotations
from pathlib import Path
import json

import numpy as np
import pandas as pd


def _frames_to_list(v):
    if isinstance(v, (list, tuple, np.ndarray)):
        return list(v)
    if isinstance(v, str) and v:
        return [x for x in v.split(",") if x]
    return []


def _prep(df: pd.DataFrame) -> pd.DataFrame:
    from .derive import normalize_jurisdiction
    df = df[df["on_topic"]].copy()
    df["jurisdiction"] = df["jurisdiction"].map(normalize_jurisdiction)
    df["frames_list"] = df["frames"].map(_frames_to_list)
    # document-family weight: split confidence across a document's segments
    seg_per_doc = df.groupby("document_id")["segment_id"].transform("count")
    df["weight"] = df["confidence"].clip(lower=0.05) / seg_per_doc
    return df


def _wmean(scores: np.ndarray, weights: np.ndarray) -> float:
    return float(np.sum(scores * weights) / np.sum(weights)) if weights.sum() else np.nan


def protectiveness_index(scored: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    a = cfg["aggregate"]
    df = _prep(scored)
    rng = np.random.default_rng(0)
    rows = []
    for (j, y, t), cell in df.groupby(["jurisdiction", "year", "tier"]):
        if len(cell) < a["min_segments_per_cell"] or pd.isna(y):
            continue
        s = cell["score"].to_numpy()
        w = cell["weight"].to_numpy()
        point = _wmean(s, w)
        # cluster bootstrap over documents
        docs = cell["document_id"].to_numpy()
        uniq = np.unique(docs)
        boot = np.empty(a["bootstrap_iters"])
        idx_by_doc = {d: np.where(docs == d)[0] for d in uniq}
        for b in range(a["bootstrap_iters"]):
            pick = rng.choice(uniq, size=len(uniq), replace=True)
            sel = np.concatenate([idx_by_doc[d] for d in pick])
            boot[b] = _wmean(s[sel], w[sel])
        # composition guard: a shift in P across years can be a real change in
        # protectiveness OR a change in the mix of what got measured. Carry the
        # mix so the two can be told apart downstream.
        mixed_share = float((cell["stance"] == "mixed").mean())
        frame_counts: dict[str, int] = {}
        for fl in cell["frames_list"]:
            for f in fl:
                frame_counts[f] = frame_counts.get(f, 0) + 1
        n = len(cell)
        frame_shares = {k: round(v / n, 3) for k, v in
                        sorted(frame_counts.items(), key=lambda kv: -kv[1])}
        rows.append({
            "jurisdiction": j, "year": int(y), "tier": t,
            "P": point, "ci_lo": float(np.nanpercentile(boot, 2.5)),
            "ci_hi": float(np.nanpercentile(boot, 97.5)),
            "n_segments": len(cell), "n_documents": len(uniq),
            "mean_confidence": round(float(cell["confidence"].mean()), 3),
            "mixed_share": round(mixed_share, 3),          # polarization proxy
            "frame_shares": json.dumps(frame_shares),
        })
    cols = ["jurisdiction", "year", "tier", "P", "ci_lo", "ci_hi",
            "n_segments", "n_documents", "mean_confidence", "mixed_share",
            "frame_shares"]
    if not rows:
        return pd.DataFrame(columns=cols)
    return pd.DataFrame(rows).sort_values(["jurisdiction", "tier", "year"])


# enforcement-facing guidance markers -> OPERATIONAL side of the gap
_ENFORCE = ("enforcement", "penalt", "compliance", "audit", "check",
            "sanction", "right to work", "civil penalty", "inspection")


def _gap_side(row) -> str | None:
    t = row["tier"]
    if t == "legislative":
        return "formal"
    if t == "adjudicative" and row.get("is_apex"):
        return "formal"
    if t == "guidance":
        txt = (str(row.get("court", "")) + " " + str(row.get("citation", ""))).lower()
        # treat all guidance as operational; enforcement-facing if markers present
        return "operational"
    return None  # deliberative + non-apex adjudicative excluded from the gap


def implementation_gap(scored: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    df = _prep(scored)
    if "is_apex" not in df.columns:
        df["is_apex"] = False
    df["side"] = df.apply(_gap_side, axis=1)
    df = df[df["side"].notna()]
    rows = []
    for (j, y), cell in df.groupby(["jurisdiction", "year"]):
        if pd.isna(y):
            continue
        f = cell[cell["side"] == "formal"]
        o = cell[cell["side"] == "operational"]
        if len(f) < 5 or len(o) < 5:
            continue
        pf = _wmean(f["score"].to_numpy(), f["weight"].to_numpy())
        po = _wmean(o["score"].to_numpy(), o["weight"].to_numpy())
        rows.append({"jurisdiction": j, "year": int(y),
                     "P_formal": pf, "P_operational": po, "gap": pf - po,
                     "n_formal": len(f), "n_operational": len(o)})
    cols = ["jurisdiction", "year", "P_formal", "P_operational", "gap",
            "n_formal", "n_operational"]
    if not rows:
        return pd.DataFrame(columns=cols)
    return pd.DataFrame(rows).sort_values(["jurisdiction", "year"])


def _readable_frames(fs: str, k: int = 3) -> str:
    try:
        d = json.loads(fs)
    except Exception:
        return ""
    return "; ".join(f"{n} ({v:.2f})" for n, v in
                     sorted(d.items(), key=lambda kv: -kv[1])[:k])


def run(scored: pd.DataFrame, cfg: dict, work_dir: Path) -> None:
    out = work_dir / "indices"
    out.mkdir(parents=True, exist_ok=True)
    pj = protectiveness_index(scored, cfg)
    # bootstrap CIs are meaningless when a cell rests on a single document
    if len(pj):
        one_doc = pj["n_documents"] < 2
        pj.loc[one_doc, ["ci_lo", "ci_hi"]] = pd.NA
    pj.to_parquet(out / "protectiveness_index.parquet", index=False)
    pj.to_csv(out / "protectiveness_index.csv", index=False)
    gap = implementation_gap(scored, cfg)
    gap.to_parquet(out / "implementation_gap.parquet", index=False)
    gap.to_csv(out / "implementation_gap.csv", index=False)

    # consolidated single results file: index rows + gap rows, one tidy schema
    rows = []
    for _, r in pj.iterrows():
        rows.append({
            "jurisdiction": r["jurisdiction"], "year": r["year"], "tier": r["tier"],
            "metric": "protectiveness", "value": round(r["P"], 3),
            "ci_lo": r["ci_lo"], "ci_hi": r["ci_hi"],
            "n_segments": r["n_segments"], "n_documents": r["n_documents"],
            "mean_confidence": r["mean_confidence"], "mixed_share": r["mixed_share"],
            "top_frames": _readable_frames(r["frame_shares"]),
        })
    for _, r in gap.iterrows():
        rows.append({
            "jurisdiction": r["jurisdiction"], "year": r["year"],
            "tier": "formal_vs_operational", "metric": "implementation_gap",
            "value": round(r["gap"], 3), "ci_lo": pd.NA, "ci_hi": pd.NA,
            "n_segments": r["n_formal"] + r["n_operational"], "n_documents": pd.NA,
            "mean_confidence": pd.NA, "mixed_share": pd.NA,
            "top_frames": f"P_formal={r['P_formal']:.3f}; P_operational={r['P_operational']:.3f}",
        })
    results = pd.DataFrame(rows).sort_values(["metric", "tier", "jurisdiction", "year"])
    results.to_csv(out / "results.csv", index=False)

    print(f"  P(j,y,t): {len(pj)} cells  ->  {out/'protectiveness_index.csv'}")
    print(f"  gap(j,y): {len(gap)} cells  ->  {out/'implementation_gap.csv'}")
    print(f"  consolidated: {len(results)} rows  ->  {out/'results.csv'}")
