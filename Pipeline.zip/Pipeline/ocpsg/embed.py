"""Dense embeddings (deck step 2) on your CUDA GPU.

Embeds scored segments for: semantic-drift tracking (drift.py) and unsupervised
topic/cluster discovery. Writes one .npy matrix aligned row-for-row with an ids
parquet, so embeddings join back to scores by position.

e5 models want an instruction prefix ("query:" / "passage:"); we use "passage:".
"""
from __future__ import annotations
from pathlib import Path

import numpy as np
import pandas as pd


def embed_segments(df: pd.DataFrame, cfg: dict, work_dir: Path) -> Path:
    from sentence_transformers import SentenceTransformer
    e = cfg["embeddings"]
    model = SentenceTransformer(e["model"], device=e["device"])
    texts = [f"passage: {t[:2000]}" for t in df["text"].fillna("").tolist()]
    vecs = model.encode(
        texts, batch_size=e["batch_size"], show_progress_bar=True,
        convert_to_numpy=True, normalize_embeddings=True,
    )
    out_dir = work_dir / "embeddings"
    out_dir.mkdir(parents=True, exist_ok=True)
    np.save(out_dir / "vectors.npy", vecs.astype("float32"))
    df[["segment_id", "document_id", "source", "tier", "jurisdiction", "year"]] \
        .reset_index(drop=True).to_parquet(out_dir / "ids.parquet")
    print(f"  embedded {len(df)} segments -> {out_dir}")
    return out_dir
