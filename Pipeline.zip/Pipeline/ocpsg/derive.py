"""Derive per-record metadata from the data rather than hard-coding it.

config.yaml previously fixed tier and jurisdiction per source, and the adapters
hard-coded apex. Most of that is actually carried in the records: `document_form`
(judgment/order vs regulation/directive) gives tier, `deciding_body_type` marks a
court, `country` / `respondent` / `referring_court_country` give jurisdiction,
and a mix of court name + document form gives apex. These helpers read those
signals off each record; the config value is used only as a fallback when the
data is silent. That means a mislabelled file, an order sitting in a judgment
dump, or a preliminary reference from one member state is classified from what it
actually is, not from an assumption baked into config.
"""
from __future__ import annotations
import re

from .schema import detect_apex

# date-like keys seen across the nine schemas, in preference order
_YEAR_KEYS = ("judgment_year", "decision_date", "date_document", "judgment_date",
              "date_lodged", "date_effect", "public_updated_at", "first_published_at",
              "judgmentdate", "kpdate", "date")

_ADJ_FORMS = {"judgment", "order", "opinion", "ruling", "decision_of_court"}
_LEG_FORMS = {"regulation", "directive", "decision", "recommendation",
              "communication", "act", "resolution"}


def derive_year(rec: dict) -> int | None:
    for k in _YEAR_KEYS:
        v = rec.get(k)
        if v:
            m = re.search(r"(19|20)\d{2}", str(v))
            if m:
                return int(m.group(0))
    return None


def normalize_jurisdiction(j: str | None) -> str:
    """Collapse messy jurisdiction strings to canonical names: HUDOC respondent
    forms ('THE UNITED KINGDOM'), FRA translation/administration suffixes
    ('France - [Swedish Translation]...'), stray quotes, and versus-strings that
    leaked from bad case-name parses ('And Others V. Germany' -> Germany)."""
    if not isinstance(j, str) or not j.strip():
        return "Unknown"
    j = j.strip().strip('"').strip()
    # a versus separator that slipped through: respondent is after the LAST ' v. '
    if re.search(r"\sv\.?\s", j, re.I):
        j = re.split(r"\s+v\.?\s+", j, flags=re.I)[-1].strip()
    j = re.split(r"\s*[-\u2013]\s*\[", j)[0].strip()   # drop "- [Swedish Translation]..."
    j = re.sub(r"\s*\(.*$", "", j).strip()             # drop "(No. 2)" etc
    j = re.sub(r"^the\s+", "", j, flags=re.I).strip()  # "The United Kingdom" -> "United Kingdom"
    j = j.strip().strip('"').strip()
    low = j.lower()
    if low in {"united kingdom", "uk", "great britain", "u.k."}:
        return "UK"
    if low in {"eu", "european union", "e.u."}:
        return "EU"
    if low in {"echr", "ecthr", "council of europe"}:
        return "ECtHR"
    if low in {"turkey", "turkiye", "t\u00fcrkiye", "t\u00fcrki\u0307ye"}:
        return "Turkey"
    if "macedonia" in low:
        return "North Macedonia"
    if not j:
        return "Unknown"
    return j.title() if (j.isupper() or j.islower()) else j


def derive_jurisdiction(rec: dict, default: str | None = None) -> str | None:
    j = _derive_jurisdiction_raw(rec, default)
    return normalize_jurisdiction(j) if j else j


def _derive_jurisdiction_raw(rec: dict, default: str | None = None) -> str | None:
    # national court applying the Charter (FRA): the deciding country
    if rec.get("country"):
        return str(rec["country"]).split("/")[0].strip()
    # FRA records that omit `country` carry it in the reference title, e.g.
    # "Austria / Constitutional Court / E1486/2017"
    if rec.get("case_reference_title"):
        head = str(rec["case_reference_title"]).split("/")[0].strip()
        if head and head.replace(" ", "").isalpha() and len(head) > 2:
            return head
    # ECtHR (HUDOC): the respondent state is the jurisdiction under review
    for k in ("respondent", "respondentOrderEng"):
        if rec.get(k):
            return str(rec[k]).split(";")[0].strip()
    # EU instruments / CJEU: EU-level
    if rec.get("celex") or str(rec.get("ecli", "")).startswith("ECLI:EU"):
        return "EU" if default in (None, "from_field") else default
    if default in (None, "from_field"):
        return None
    return default


def derive_referring_country(rec: dict) -> str:
    """For EU preliminary references, the member state the question came from.
    Kept as metadata: jurisdiction stays EU (it is CJEU jurisprudence) but the
    origin is recorded so it can be analysed separately."""
    return str(rec.get("referring_court_country") or "").strip()


def derive_tier(rec: dict, default: str | None = None) -> str | None:
    dbt = str(rec.get("deciding_body_type") or "").lower()
    if "court" in dbt or "tribunal" in dbt:
        return "adjudicative"
    form = str(rec.get("document_form") or "").lower()
    if form in _ADJ_FORMS:
        return "adjudicative"
    if form in _LEG_FORMS and rec.get("celex"):     # EU legislative act
        return "legislative"
    if rec.get("document_type") and not rec.get("deciding_body"):   # GOV.UK guidance
        return "guidance"
    return default


def derive_apex(rec: dict, court: str = "") -> bool:
    if detect_apex(court):
        return True
    form = str(rec.get("document_form") or "").lower()
    is_eu_court = (rec.get("celex") or str(rec.get("ecli", "")).startswith("ECLI:EU"))
    if is_eu_court and form in _ADJ_FORMS:          # CJEU / General Court
        return True
    if rec.get("appno") or rec.get("itemid") or rec.get("respondent"):  # ECtHR
        return True
    return False


def derive_all(rec: dict, tier_default=None, jur_default=None, court="") -> dict:
    # "from_field" is a config sentinel meaning "read it off the record", never a
    # real jurisdiction, so it must not survive as a fallback value.
    jur = derive_jurisdiction(rec, jur_default)
    if not jur or jur == "from_field":
        jur = None if jur_default in (None, "from_field") else jur_default
    if not jur:
        jur = "Unknown"
    return {
        "year": derive_year(rec),
        "tier": derive_tier(rec, tier_default) or tier_default,
        "jurisdiction": jur,
        "referring_country": derive_referring_country(rec),
        "is_apex": derive_apex(rec, court),
    }
