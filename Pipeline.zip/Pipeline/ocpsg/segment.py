"""Segmentation for sources that arrive as one big `full_text` blob.

Pre-segmented sources (EUR-Lex, FRA, govuk, HUDOC) skip this entirely — their
adapters already yield one Segment per provided chunk. Hansard speech turns and
UK judgments need splitting so that stance is scored at a doctrinally meaningful
grain rather than per whole judgment.

Strategy: split on blank lines first; if a block is still very long, fall back
to numbered-paragraph boundaries common in UK/EU judgments ("1.", "23.", "§4"),
then to a sentence-aware hard cap. Cheap, deterministic, no model needed.
"""
from __future__ import annotations
import re
from typing import Iterator

_PARA_NUM = re.compile(r"(?m)^\s*(?:§\s*)?\d{1,4}[\.\)]\s+")
_SENT = re.compile(r"(?<=[\.\?\!])\s+(?=[A-Z\"'\(])")

TARGET_CHARS = 1400      # ~300-350 tokens; a healthy stance-scoring grain
HARD_MAX = 2600


def _by_sentences(block: str, cap: int) -> Iterator[str]:
    sents, cur = _SENT.split(block), ""
    for s in sents:
        if len(cur) + len(s) + 1 > cap and cur:
            yield cur.strip()
            cur = s
        else:
            cur = f"{cur} {s}".strip()
    if cur.strip():
        yield cur.strip()


def split_document(full_text: str) -> list[str]:
    if not full_text or not full_text.strip():
        return []
    full_text = full_text.replace("\r\n", "\n")

    # 1) blank-line blocks
    blocks = [b.strip() for b in re.split(r"\n\s*\n", full_text) if b.strip()]
    if len(blocks) <= 1:
        # 2) numbered-paragraph boundaries (judgments rarely use blank lines)
        idxs = [m.start() for m in _PARA_NUM.finditer(full_text)]
        if len(idxs) > 1:
            blocks = [full_text[a:b].strip()
                      for a, b in zip(idxs, idxs[1:] + [len(full_text)])]
        else:
            blocks = [full_text]

    out: list[str] = []
    for b in blocks:
        if len(b) <= HARD_MAX:
            out.append(b)
        else:
            out.extend(_by_sentences(b, TARGET_CHARS))
    return [o for o in out if len(o) >= 40]   # drop scraps
