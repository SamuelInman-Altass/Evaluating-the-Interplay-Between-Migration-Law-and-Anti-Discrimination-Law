"""Zero-shot protectiveness scorer (deck step 3).

Sentiment is redefined per the deck as *stance toward legal protection of
religious minorities in labour-migration contexts*, NOT generic positivity.
For each segment the model returns:
  - stance        : protective | restrictive | mixed | neutral
  - score         : continuous in [-1, +1]  (+1 strongly protective)
  - frames        : subset of the 10 doctrinal frames (multi-label)
  - on_topic      : bool  (kills lexical false positives like the Re L "veil" hit)
  - confidence    : 0-1   (feeds aggregation weighting + bootstrap)

Engineering: every call is cached in SQLite keyed by (model, prompt-hash), so
re-runs and crashes cost nothing. Calls are async with a concurrency cap and
exponential backoff. A cost estimator runs first so you never start a six-figure
token job blind.
"""
from __future__ import annotations
import asyncio
import hashlib
import json
import sqlite3
import time
from pathlib import Path

import numpy as np
import pandas as pd
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

from .schema import FRAMES

SYSTEM = (
    "You are a legal-linguistics annotator for a study of how EU/UK migration "
    "law interacts with religious anti-discrimination law. You score a single "
    "text segment for its STANCE TOWARD LEGAL PROTECTION of religious minorities "
    "in labour-migration contexts. This is not generic sentiment: protective "
    "language mandates rights, allocates burdens onto the state/employer, applies "
    "strict scrutiny, or widens remedies; restrictive language makes protection "
    "conditional, shifts burdens onto the rights-holder, invokes neutrality/"
    "public-order/proportionality to limit a claim, or expands compliance/"
    "enforcement exposure. Surface positivity can mask restriction; judge legal "
    "effect, not tone."
)

_FRAME_DESC = (
    "manifestation: religion as a right to be exercised; "
    "dignity_pluralism: minority presence as part of democratic order; "
    "indirect_discrimination: a neutral rule imposing a group-specific burden; "
    "strict_scrutiny: interference needs weighty justification / close review; "
    "access_to_remedies: complaint or enforcement channels framed as protection; "
    "integration_cohesion: protection made conditional on fitting governing norms; "
    "neutrality_corporate: religious visibility reframed as operational disruption; "
    "public_order_border: status/border control taking precedence over equal treatment; "
    "proportionality_balancing: the claim absorbed into managerial or state interests; "
    "compliance_audit: frontline actors incentivised to avoid regulatory risk."
)

PROMPT_TMPL = (
    "Frames (choose all that apply, or none):\n{frames}\n\n"
    "Segment metadata: tier={tier}; jurisdiction={jur}; court/source={court}; year={year}.\n\n"
    "Segment:\n\"\"\"\n{text}\n\"\"\"\n\n"
    "Return ONLY a JSON object, no prose, with keys exactly: "
    'stance (one of protective|restrictive|mixed|neutral), '
    "score (number in [-1,1]), frames (array of frame keys from the list above), "
    "on_topic (boolean: does this segment actually bear on religion/belief and/or "
    "migration-status rights, vs. an incidental keyword match), "
    "confidence (number 0-1)."
)

PROMPT_VERSION = "v2"   # bump to invalidate cache when the prompt/anchors change

# Few-shot anchors. Zero-shot lets the model's private notion of "protective"
# drift across 9 sources; these four fix the scale to the deck's definition by
# example, cutting label variance. They are sent as prior turns, so the model
# sees the exact output contract before the real segment. Curated to span the
# space: clearly protective, clearly restrictive, genuinely mixed, off-topic
# keyword hit. Edit these if your gold set reveals systematic disagreement —
# they are the cheapest lever on instrument quality.
FEW_SHOT: list[tuple[str, dict]] = [
    (
        "The court gets its own impression directly at a hearing; where an "
        "asylum claim turns on the credibility of the applicant's religious "
        "conversion, Article 47(2) of the Charter requires an oral hearing, and "
        "its omission infringes the constitutionally guaranteed right.",
        {"stance": "protective", "score": 0.8,
         "frames": ["access_to_remedies", "strict_scrutiny", "manifestation"],
         "on_topic": True, "confidence": 0.9},
    ),
    (
        "Where an administrative procedure granting a party hearing has already "
        "taken place, the waiver of an oral hearing is permissible if the facts "
        "appear sufficiently clarified from the file, and the applicant bears "
        "the burden of substantiating asylum-relevant persecution.",
        {"stance": "restrictive", "score": -0.55,
         "frames": ["proportionality_balancing", "public_order_border"],
         "on_topic": True, "confidence": 0.8},
    ),
    (
        "A prohibition on visible religious symbols may pursue a legitimate aim "
        "of neutrality in relations with customers, provided it is applied "
        "consistently and limited to what is strictly necessary.",
        {"stance": "mixed", "score": -0.1,
         "frames": ["neutrality_corporate", "proportionality_balancing",
                    "indirect_discrimination"],
         "on_topic": True, "confidence": 0.75},
    ),
    (
        "The reference quantity to be exempt from the additional levy was equal "
        "to the quantity of milk delivered by a producer during the reference "
        "year, which in the case of the Netherlands was 1983.",
        {"stance": "neutral", "score": 0.0, "frames": [],
         "on_topic": False, "confidence": 0.95},
    ),
]


def _prompt(row: dict) -> str:
    return PROMPT_TMPL.format(
        frames=_FRAME_DESC, tier=row["tier"], jur=row["jurisdiction"],
        court=(row.get("court") or "")[:120], year=row.get("year"),
        text=(row["text"] or "")[:6000],
    )


def _messages(row: dict) -> list[dict]:
    """Full message list: few-shot anchors as prior turns, then the segment."""
    msgs: list[dict] = []
    for text, answer in FEW_SHOT:
        stub = {"tier": "adjudicative", "jurisdiction": "EU", "court": "",
                "year": None, "text": text}
        msgs.append({"role": "user", "content": _prompt(stub)})
        msgs.append({"role": "assistant", "content": json.dumps(answer)})
    msgs.append({"role": "user", "content": _prompt(row)})
    return msgs


def _key(model: str, prompt: str) -> str:
    return hashlib.sha256(f"{PROMPT_VERSION}|{model}|{prompt}".encode()).hexdigest()


class Cache:
    def __init__(self, path: Path):
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.execute("CREATE TABLE IF NOT EXISTS c (k TEXT PRIMARY KEY, v TEXT)")
        self.db.commit()
        self._lock = asyncio.Lock()

    def get(self, k: str):
        r = self.db.execute("SELECT v FROM c WHERE k=?", (k,)).fetchone()
        return json.loads(r[0]) if r else None

    async def put(self, k: str, v: dict):
        async with self._lock:
            self.db.execute("INSERT OR REPLACE INTO c VALUES (?,?)", (k, json.dumps(v)))
            self.db.commit()


def _parse(txt: str) -> dict:
    txt = txt.strip()
    if txt.startswith("```"):
        txt = txt.strip("`").split("\n", 1)[-1]
    start, end = txt.find("{"), txt.rfind("}")
    obj = json.loads(txt[start:end + 1])
    frames = [f for f in obj.get("frames", []) if f in FRAMES]
    score = float(obj.get("score", 0.0))
    return {
        "stance": obj.get("stance", "neutral"),
        "score": max(-1.0, min(1.0, score)),
        "frames": frames,
        "on_topic": bool(obj.get("on_topic", True)),
        "confidence": max(0.0, min(1.0, float(obj.get("confidence", 0.5)))),
    }


async def _score_one(client, model, max_tokens, row, cache, sem, temperature=0.0):
    prompt = _prompt(row)
    # temperature>0 runs are for stability estimation and must not poison the
    # deterministic cache, so fold it into the key.
    k = _key(model, prompt if temperature == 0 else f"{prompt}|T={temperature}")
    cached = cache.get(k) if temperature == 0 else None
    if cached is not None:
        return {**row_min(row), **cached, "cached": True}

    @retry(stop=stop_after_attempt(5),
           wait=wait_exponential(multiplier=2, min=2, max=60),
           retry=retry_if_exception_type(Exception))
    async def _call():
        async with sem:
            return await client.messages.create(
                model=model, max_tokens=max_tokens, system=SYSTEM,
                temperature=temperature, messages=_messages(row),
            )

    resp = await _call()
    try:
        parsed = _parse(resp.content[0].text)
    except Exception:
        parsed = {"stance": "neutral", "score": 0.0, "frames": [],
                  "on_topic": False, "confidence": 0.0}
    if temperature == 0:
        await cache.put(k, parsed)
    return {**row_min(row), **parsed, "cached": False}


def row_min(row: dict) -> dict:
    return {kk: row[kk] for kk in
            ("segment_id", "document_id", "source", "tier", "jurisdiction",
             "year", "is_apex", "char_count")}


def estimate_cost(df: pd.DataFrame, model: str) -> dict:
    # ~4 chars/token; output ~120 tokens/segment. Prices are indicative only —
    # confirm current rates in the Anthropic console before a large run.
    rates = {  # USD per 1M tokens (input, output) — placeholders, verify!
        "claude-sonnet-4-6": (3.0, 15.0),
        "claude-haiku-4-5-20251001": (0.80, 4.0),
    }
    in_tok = (df["char_count"].clip(upper=6000).sum() + 900 * len(df)) / 4
    out_tok = 120 * len(df)
    pin, pout = rates.get(model, (3.0, 15.0))
    usd = in_tok / 1e6 * pin + out_tok / 1e6 * pout
    return {"segments": len(df), "est_input_tokens": int(in_tok),
            "est_output_tokens": int(out_tok), "est_usd": round(usd, 2)}


async def score_frame(df: pd.DataFrame, cfg: dict, work_dir: Path,
                      limit: int | None = None) -> pd.DataFrame:
    from anthropic import AsyncAnthropic
    s = cfg["stance"]
    model = s["model"]
    cache = Cache(work_dir / s["cache_db"])
    client = AsyncAnthropic()
    sem = asyncio.Semaphore(s["max_concurrency"])
    rows = df.to_dict("records")
    if limit:
        rows = rows[:limit]
    out, t0 = [], time.time()
    tasks = [_score_one(client, model, s["max_tokens"], r, cache, sem) for r in rows]
    for i, fut in enumerate(asyncio.as_completed(tasks), 1):
        out.append(await fut)
        if i % 500 == 0:
            print(f"  scored {i}/{len(tasks)}  ({i/(time.time()-t0):.1f}/s)")
    return pd.DataFrame(out)


async def score_stability(df: pd.DataFrame, cfg: dict, work_dir: Path,
                          n_segments: int = 100, k: int = 5,
                          temperature: float = 0.7) -> pd.DataFrame:
    """Measure the instrument's own noise floor: score the same segments k times
    at temperature>0 and report per-segment stance agreement and score SD. If
    the model disagrees with itself this often, no downstream CI can be tighter.
    Report this alongside human-agreement in the paper."""
    from anthropic import AsyncAnthropic
    s = cfg["stance"]
    cache = Cache(work_dir / s["cache_db"])
    client = AsyncAnthropic()
    sem = asyncio.Semaphore(s["max_concurrency"])
    sample = df.sample(min(n_segments, len(df)), random_state=0).to_dict("records")
    rows = []
    for r in sample:
        runs = await asyncio.gather(*[
            _score_one(client, s["model"], s["max_tokens"], r, cache, sem, temperature)
            for _ in range(k)])
        stances = [x["stance"] for x in runs]
        scores = [x["score"] for x in runs]
        modal = max(set(stances), key=stances.count)
        rows.append({
            "segment_id": r["segment_id"], "source": r["source"],
            "modal_stance": modal,
            "stance_agreement": stances.count(modal) / k,
            "score_mean": float(np.mean(scores)), "score_sd": float(np.std(scores)),
        })
    rep = pd.DataFrame(rows)
    out = work_dir / "indices"; out.mkdir(parents=True, exist_ok=True)
    rep.to_csv(out / "stance_stability.csv", index=False)
    print(f"  stability: mean stance-agreement={rep['stance_agreement'].mean():.2f}, "
          f"mean score SD={rep['score_sd'].mean():.3f} -> {out/'stance_stability.csv'}")
    return rep
