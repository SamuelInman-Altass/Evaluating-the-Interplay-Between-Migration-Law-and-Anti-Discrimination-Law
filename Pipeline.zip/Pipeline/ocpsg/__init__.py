"""OCPSG protectiveness-index pipeline.

Implements the deck pipeline: ingest -> segment -> relevance gate ->
zero-shot stance/frame scoring -> embeddings -> P(j,y,t) aggregation
with bootstrap CIs -> implementation-gap statistic -> semantic drift ->
linkage interface for Section V outcome indicators.
"""
__version__ = "0.1.0"
