"""Local stance backends - no Anthropic API, no key, no per-token cost.

Two options, selected by config `stance.backend`:

  nli    : a zero-shot NLI classifier (HuggingFace transformers). Scores each
           segment by entailment against natural-language hypotheses for stance,
           on-topic and each frame. Runs on Apple Silicon (mps) or CPU, is fully
           offline after the one-time model download, and is DETERMINISTIC - so
           there is no self-inconsistency noise floor, and re-runs are exact.
           This is the practical default for a large corpus on a laptop.

  ollama : a local generative model served by Ollama (http://localhost:11434),
           using the same prompt and JSON contract as the Anthropic path. Higher
           quality on subtle legal stance than NLI, slower, needs Ollama running
           and a model pulled (e.g. `ollama pull llama3.1:8b`).

Both return the same columns as the Anthropic scorer (stance, score, frames,
on_topic, confidence), so aggregation, drift and validation are unchanged. Which
one to trust is an empirical question - build the gold set and check the
agreement, exactly as you would for the API scorer.
"""
from __future__ import annotations
from pathlib import Path
import hashlib
import json
import time
import urllib.request

import pandas as pd

from .schema import FRAMES
from .stance import Cache, row_min, _parse, SYSTEM, _messages

# --------------------------------------------------------------------------- #
# Hypotheses for the NLI backend
# --------------------------------------------------------------------------- #
STANCE_HYP = {
    "protective": "This passage expands or strengthens legal protection for religious minorities or migrants.",
    "restrictive": "This passage restricts, limits or narrows legal protection for religious minorities or migrants.",
    "neutral": "This passage is procedural, factual or definitional and takes no position on protection.",
}
ONTOPIC_HYP = "This passage concerns religion, belief, or the rights of people with insecure migration status."
FRAME_HYP = {
    "manifestation": "This passage treats religion as a right to be exercised, such as dress, worship, observance or conversion.",
    "dignity_pluralism": "This passage frames minority presence as part of a pluralist democratic order deserving equal standing.",
    "indirect_discrimination": "This passage concerns a neutral rule that imposes a particular burden on a religious or migrant group.",
    "strict_scrutiny": "This passage says an interference with rights needs weighty justification or close judicial review.",
    "access_to_remedies": "This passage frames complaint, hearing or enforcement channels as a protection, such as the right to be heard.",
    "integration_cohesion": "This passage makes protection conditional on integration, social cohesion or adopting shared norms.",
    "neutrality_corporate": "This passage reframes religious visibility as operational or commercial disruption, such as workplace neutrality.",
    "public_order_border": "This passage gives priority to immigration control, border enforcement or public order over equal treatment.",
    "proportionality_balancing": "This passage absorbs a rights claim into a balancing exercise resolved in favour of managerial or state interests.",
    "compliance_audit": "This passage concerns penalties, checks, audits or enforcement duties that push actors to avoid regulatory risk.",
}


def _nli_pipeline(cfg):
    from transformers import pipeline
    import torch

    def build(dev):
        device = torch.device(dev) if dev in ("mps", "cuda") else torch.device("cpu")
        return pipeline("zero-shot-classification",
                        model=cfg["stance"].get("nli_model",
                              "MoritzLaurer/deberta-v3-base-zeroshot-v2.0"),
                        device=device)
    want = cfg["stance"].get("device", "cpu")
    try:
        return build(want)
    except Exception as e:
        if want != "cpu":
            print(f"  ({want} unavailable for NLI: {e}; using cpu)")
            return build("cpu")
        raise


def make_scorer(cfg, backend="nli"):
    """Return a callable rows -> list[pred dict]. Builds the model ONCE (so it
    isn't reloaded per shard) and classifies in small batches (so memory stays
    flat regardless of how many rows are passed in)."""
    s = cfg["stance"]
    bs = int(s.get("batch_size", 8))
    if backend == "nli":
        scorer = NLIScorer(cfg)

        def f(rows):
            out = []
            for i in range(0, len(rows), bs):
                chunk = [(r.get("text") or "")[:2000] for r in rows[i:i + bs]]
                out.extend(scorer.score(chunk))
            return out
        return f
    if backend == "ollama":
        url = s.get("ollama_url", "http://localhost:11434")
        model = s.get("ollama_model", "llama3.1:8b")

        def f(rows):
            out = []
            for r in rows:
                try:
                    out.append(_parse(_ollama_chat(
                        url, model, [{"role": "system", "content": SYSTEM}] + _messages(r))))
                except Exception:
                    out.append({"stance": "neutral", "score": 0.0, "frames": [],
                                "on_topic": False, "confidence": 0.0})
            return out
        return f
    raise ValueError(f"unknown local backend {backend!r}")


class NLIScorer:
    """classifier is injectable for testing; otherwise a transformers pipeline."""
    def __init__(self, cfg, classifier=None):
        self.s = cfg["stance"]
        self.clf = classifier if classifier is not None else _nli_pipeline(cfg)
        self.ont_t = self.s.get("ontopic_threshold", 0.5)
        self.fr_t = self.s.get("frame_threshold", 0.5)

    def _cls(self, texts, labels, multi_label):
        res = self.clf(texts, list(labels), multi_label=multi_label)
        if isinstance(res, dict):
            res = [res]
        return [dict(zip(r["labels"], r["scores"])) for r in res]

    def score(self, texts: list[str]) -> list[dict]:
        # one classification call per batch (all hypotheses at once) instead of
        # three - the pipeline overhead was tripling the cost per segment.
        all_labels = (list(STANCE_HYP.values()) + [ONTOPIC_HYP]
                      + list(FRAME_HYP.values()))
        res = self._cls(texts, all_labels, True)
        inv_st = {v: k for k, v in STANCE_HYP.items()}
        inv_fr = {v: k for k, v in FRAME_HYP.items()}
        out = []
        for r in res:
            s = {inv_st[k]: v for k, v in r.items() if k in inv_st}
            prot, restr, neu = s["protective"], s["restrictive"], s["neutral"]
            score = round(prot - restr, 3)
            if prot >= 0.5 and restr >= 0.5:
                stance = "mixed"
            elif max(prot, restr) < 0.4 or neu >= max(prot, restr) + 0.05:
                stance = "neutral"
            elif prot > restr:
                stance = "protective"
            else:
                stance = "restrictive"
            on_topic = r.get(ONTOPIC_HYP, 0.0) >= self.ont_t
            frames = [inv_fr[k] for k, v in r.items()
                      if k in inv_fr and v >= self.fr_t]
            out.append({"stance": stance, "score": max(-1.0, min(1.0, score)),
                        "frames": frames, "on_topic": bool(on_topic),
                        "confidence": round(float(max(prot, restr, neu)), 3)})
        return out


def _run_nli(df, cfg, work_dir, limit):
    scorer = NLIScorer(cfg)
    cache = Cache(work_dir / cfg["stance"].get("cache_db", "llm_cache.sqlite"))
    model = cfg["stance"].get("nli_model", "nli")
    bs = cfg["stance"].get("batch_size", 16)
    rows = df.to_dict("records")
    if limit:
        rows = rows[:limit]
    out, t0 = [], time.time()
    for i in range(0, len(rows), bs):
        batch = rows[i:i + bs]
        keys = [hashlib.sha256(f"nli|{model}|{r['text']}".encode()).hexdigest()
                for r in batch]
        cached = [cache.get(k) for k in keys]
        todo = [j for j, c in enumerate(cached) if c is None]
        if todo:
            preds = scorer.score([batch[j]["text"][:2000] for j in todo])
            import asyncio
            for j, p in zip(todo, preds):
                cached[j] = p
                asyncio.run(cache.put(keys[j], p))
        for r, c in zip(batch, cached):
            out.append({**row_min(r), **c, "cached": True})
        if (i // bs) % 20 == 0 and i:
            print(f"  scored {i}/{len(rows)}  ({i/(time.time()-t0):.1f}/s)")
    return pd.DataFrame(out)


# --------------------------------------------------------------------------- #
# Ollama backend
# --------------------------------------------------------------------------- #
def _ollama_chat(url, model, messages, timeout=120):
    payload = json.dumps({"model": model, "messages": messages, "stream": False,
                          "format": "json", "options": {"temperature": 0}}).encode()
    req = urllib.request.Request(f"{url}/api/chat", data=payload,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read())["message"]["content"]


def _run_ollama(df, cfg, work_dir, limit):
    s = cfg["stance"]
    url = s.get("ollama_url", "http://localhost:11434")
    model = s.get("ollama_model", "llama3.1:8b")
    cache = Cache(work_dir / s.get("cache_db", "llm_cache.sqlite"))
    rows = df.to_dict("records")
    if limit:
        rows = rows[:limit]
    import asyncio
    out, t0 = [], time.time()
    for i, r in enumerate(rows, 1):
        key = hashlib.sha256(f"ollama|{model}|{r['text']}".encode()).hexdigest()
        c = cache.get(key)
        if c is None:
            messages = [{"role": "system", "content": SYSTEM}] + _messages(r)
            try:
                c = _parse(_ollama_chat(url, model, messages))
            except Exception:
                c = {"stance": "neutral", "score": 0.0, "frames": [],
                     "on_topic": False, "confidence": 0.0}
            asyncio.run(cache.put(key, c))
        out.append({**row_min(r), **c, "cached": True})
        if i % 200 == 0:
            print(f"  scored {i}/{len(rows)}  ({i/(time.time()-t0):.1f}/s)")
    return pd.DataFrame(out)


def score_frame_local(df, cfg, work_dir: Path, limit=None, backend="nli") -> pd.DataFrame:
    if backend == "nli":
        return _run_nli(df, cfg, work_dir, limit)
    if backend == "ollama":
        return _run_ollama(df, cfg, work_dir, limit)
    raise ValueError(f"unknown local backend {backend!r}")
