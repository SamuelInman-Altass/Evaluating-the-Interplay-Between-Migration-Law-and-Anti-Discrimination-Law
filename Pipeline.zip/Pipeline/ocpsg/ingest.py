"""Streaming ingestion.

Reads each source file *without loading it into memory* (the EUR-Lex caselaw
file alone is 4 GB), runs the adapter + relevance gate, and writes normalised
Segments to parquet shards under work_dir/segments/<source>/.

Handles three physical shapes: a top-level JSON array (`[ {...}, {...} ]`),
JSON-lines (`{...}\n{...}`), and a wrapped object where the records sit under a
key alongside a metadata header (`{"metadata": {...}, "documents": [...]}` or
`{..., "cases": [...]}`). For wrapped files set `records_key` in config, or let
it autodetect. Array/wrapped reading uses ijson so memory stays flat.
"""
from __future__ import annotations
import json
import os
from pathlib import Path
from typing import Iterator

import ijson
import pandas as pd
from tqdm import tqdm

from .adapters import ADAPTERS
from .relevance import passes

SHARD_ROWS = 50_000

# keys a wrapped object might store its record array under
RECORD_ARRAY_KEYS = ("documents", "cases", "records", "data", "items", "results", "rows")
# fields that mark a dict as a record itself (=> the file is JSON-lines)
RECORD_MARKERS = ("full_text", "segment_text", "text", "texts", "case_id",
                  "celex", "document_id")


def _iter_records(path: Path, records_key: str | None = None) -> Iterator[dict]:
    with open(path, "rb") as f:
        first = f.read(1)
        while first and first.isspace():
            first = f.read(1)

    if first == b"[":                                   # bare array
        with open(path, "rb") as f:
            yield from ijson.items(f, "item")
        return
    if first != b"{":
        raise ValueError(f"{path}: not JSON array/object (first byte {first!r})")

    if records_key:                                     # explicit wrapped key
        with open(path, "rb") as f:
            yield from ijson.items(f, f"{records_key}.item")
        return

    # peek the first ~1 MB (memory-safe: never loads a multi-GB file to detect)
    with open(path, "r", encoding="utf-8") as f:
        head = f.read(1_000_000)
    nl = head.find("\n")
    line1 = head[:nl] if nl != -1 else head
    try:
        parsed = json.loads(line1)
    except Exception:
        parsed = None

    if isinstance(parsed, dict) and any(m in parsed for m in RECORD_MARKERS):
        with open(path, "r", encoding="utf-8") as f:    # JSON-lines
            for line in f:
                line = line.strip().rstrip(",")
                if line and line[0] == "{":
                    try:
                        yield json.loads(line)
                    except json.JSONDecodeError:
                        continue
        return

    # wrapped object: find the record array key by streaming a trial item
    key = None
    for k in RECORD_ARRAY_KEYS:
        try:
            with open(path, "rb") as f:
                next(ijson.items(f, f"{k}.item"))
            key = k
            break
        except (StopIteration, Exception):
            continue
    if not key:
        raise ValueError(f"{path}: object with no detectable record array "
                         f"(tried {RECORD_ARRAY_KEYS}; set records_key in config)")
    with open(path, "rb") as f:
        yield from ijson.items(f, f"{key}.item")


def ingest_source(src: dict, base_dir: Path, work_dir: Path) -> dict:
    """Stream one source -> parquet shards. Returns a stats dict."""
    path = base_dir / src["path"]
    if not path.exists():
        raise FileNotFoundError(path)
    adapter = ADAPTERS[src["adapter"]]
    out_dir = work_dir / "segments" / src["name"]
    out_dir.mkdir(parents=True, exist_ok=True)

    buf, shard, kept, dropped, n_rec = [], 0, 0, 0, 0
    pbar = tqdm(desc=f"ingest {src['name']}", unit="rec")
    for rec in _iter_records(path, src.get("records_key")):
        n_rec += 1
        pbar.update(1)
        for seg in adapter(rec, src["name"], src.get("tier"), src.get("jurisdiction")):
            if not seg.text or len(seg.text) < 40:
                continue
            keep, hits = passes(seg.text, src["relevance"])
            if not keep:
                dropped += 1
                continue
            row = seg.to_row()
            if hits and not row["cluster_labels"]:
                row["cluster_labels"] = ",".join(hits)
            buf.append(row)
            kept += 1
            if len(buf) >= SHARD_ROWS:
                _flush(buf, out_dir, shard); shard += 1; buf = []
    if buf:
        _flush(buf, out_dir, shard)
    pbar.close()
    stats = {"source": src["name"], "records": n_rec, "segments_kept": kept,
             "segments_dropped_by_gate": dropped}
    (out_dir / "_stats.json").write_text(json.dumps(stats, indent=2))
    return stats


def _flush(buf: list[dict], out_dir: Path, shard: int) -> None:
    pd.DataFrame(buf).to_parquet(out_dir / f"part-{shard:05d}.parquet", index=False)


def ingest_all(cfg: dict) -> list[dict]:
    base = Path(os.path.expanduser(cfg["base_dir"]))
    work = Path(os.path.expanduser(cfg["work_dir"]))
    work.mkdir(parents=True, exist_ok=True)
    stats = []
    for src in cfg["sources"]:
        try:
            stats.append(ingest_source(src, base, work))
        except FileNotFoundError as e:
            print(f"  [skip] {src['name']}: file not found ({e})")
    (work / "ingest_stats.json").write_text(json.dumps(stats, indent=2))
    return stats
