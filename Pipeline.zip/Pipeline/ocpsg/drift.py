"""Semantic drift (deck step 2 / slide 7).

Tracks how the *contextual meaning* of target terms ("neutrality",
"integration", "reasonable accommodation", ...) moves over time. For each term
and year we take the centroid of embeddings of segments containing that term,
then report cosine distance from the term's earliest-year centroid. Rising
distance = the term is being used in systematically different contexts — e.g.
"neutrality" drifting from a pluralism context toward a corporate-image /
restriction context, which slide 7 frames as inflection point 2.
"""
from __future__ import annotations
from pathlib import Path

import numpy as np
import pandas as pd


def track_drift(cfg: dict, work_dir: Path) -> pd.DataFrame:
    emb_dir = work_dir / "embeddings"
    vecs = np.load(emb_dir / "vectors.npy")
    ids = pd.read_parquet(emb_dir / "ids.parquet")
    # need text to find term occurrences: pull from the scored frame
    scored = pd.read_parquet(work_dir / "scored.parquet")[["segment_id", "text"]]
    ids = ids.merge(scored, on="segment_id", how="left")
    ids["row"] = np.arange(len(ids))

    rows = []
    for term in cfg["drift"]["terms"]:
        mask = ids["text"].fillna("").str.contains(rf"\b{term}\b", case=False, regex=True)
        sub = ids[mask & ids["year"].notna()]
        if sub.empty:
            continue
        cents = {}
        for y, g in sub.groupby("year"):
            cents[int(y)] = vecs[g["row"].to_numpy()].mean(axis=0)
        base_year = min(cents)
        base = cents[base_year]
        for y in sorted(cents):
            v = cents[y]
            cos = float(np.dot(v, base) /
                        (np.linalg.norm(v) * np.linalg.norm(base) + 1e-9))
            rows.append({"term": term, "year": y, "base_year": base_year,
                         "cosine_to_base": cos, "drift": 1 - cos,
                         "n": int((sub["year"] == y).sum())})
    cols = ["term", "year", "base_year", "cosine_to_base", "drift", "n"]
    out = (pd.DataFrame(columns=cols) if not rows
           else pd.DataFrame(rows).sort_values(["term", "year"]))
    (work_dir / "indices").mkdir(parents=True, exist_ok=True)
    out.to_csv(work_dir / "indices" / "semantic_drift.csv", index=False)
    print(f"  drift series for {out['term'].nunique()} terms "
          f"-> {work_dir/'indices'/'semantic_drift.csv'}")
    return out
